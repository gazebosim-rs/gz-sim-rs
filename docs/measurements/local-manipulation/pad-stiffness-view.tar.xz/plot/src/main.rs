// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Recover the geometric overlap on each sphere/box face from native replay.
use glam::{DQuat, DVec3};
use plotters::prelude::*;
use serde_json::{Value, json};
use std::{
    error::Error,
    fs::File,
    io::{BufRead, BufReader},
    path::Path,
};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
struct Reading {
    seconds: f64,
    compression_mm: [f64; 2],
    height_m: f64,
}
fn read(dir: &Path) -> Result<Vec<Reading>> {
    let mut samples = Vec::new();
    for line in BufReader::new(File::open(dir.join("frames.jsonl"))?).lines() {
        let frame: Value = serde_json::from_str(&line?)?;
        if frame["kind"] != "frame" {
            continue;
        }
        let scene: Value = serde_json::from_str(frame["scene"].as_str().ok_or("missing scene")?)?;
        let nanos = scene["seconds"].as_u64().ok_or("clock")? * 1_000_000_000
            + scene["nanoseconds"].as_u64().ok_or("clock fraction")?;
        if nanos != samples.len() as u64 * 250_000_000 {
            return Err("expected 250 ms captures".into());
        }
        let visuals = scene["visuals"].as_array().ok_or("visuals")?;
        let part = |name: &str| {
            visuals
                .iter()
                .find(|v| v["name"] == name)
                .ok_or("missing visual")
        };
        let center = |v: &Value| -> Result<DVec3> {
            Ok(DVec3::from_array(serde_json::from_value(
                v["translation"].clone(),
            )?))
        };
        let sphere = part("default::parcel::body::sphere")?;
        let p = center(sphere)?;
        let radius = sphere["shape"]["radius"]
            .as_f64()
            .ok_or("sphere geometry")?;
        let mut compression = [0.; 2];
        for (side, pad_name) in [
            "default::gripper::left::pad",
            "default::gripper::right::pad",
        ]
        .iter()
        .enumerate()
        {
            let pad = part(pad_name)?;
            let q = DQuat::from_array(serde_json::from_value(pad["rotation"].clone())?);
            let half =
                0.5 * DVec3::from_array(serde_json::from_value(pad["shape"]["size"].clone())?);
            let local = q.conjugate() * (p - center(pad)?);
            let direction = if side == 0 { 1. } else { -1. };
            if local.x * direction <= half.x || local.y.abs() >= half.y || local.z.abs() >= half.z {
                return Err("expected contact with both inner pad faces".into());
            }
            compression[side] = (radius + half.x - direction * local.x) * 1000.;
        }
        samples.push(Reading {
            seconds: nanos as f64 * 1e-9,
            compression_mm: compression,
            height_m: p.z,
        });
    }
    if samples.len() != 81 {
        return Err("expected 20 s of native measurements".into());
    }
    Ok(samples)
}
fn main() -> Result<()> {
    let [control, authored, plot, data]: [String; 4] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected CONTROL AUTHORED SVG JSON")?;
    let control = read(Path::new(&control))?;
    let authored = read(Path::new(&authored))?;
    let last = |data: &[Reading]| data[data.len() - 1].compression_mm;
    let mut doc = json!({"columns":["time_s","default_left_mm","default_right_mm","authored_left_mm","authored_right_mm","default_parcel_z_m","authored_parcel_z_m"],"rows":[]});
    for (a, b) in control.iter().zip(&authored) {
        doc["rows"].as_array_mut().unwrap().push(json!([
            a.seconds,
            a.compression_mm[0],
            a.compression_mm[1],
            b.compression_mm[0],
            b.compression_mm[1],
            a.height_m,
            b.height_m
        ]));
    }
    std::fs::write(data, serde_json::to_string_pretty(&doc)?)?;
    let area = SVGBackend::new(&plot, (850, 370)).into_drawing_area();
    area.fill(&WHITE)?;
    let ink = RGBColor(35, 46, 59);
    let gray = RGBColor(82, 96, 110);
    let blue = RGBColor(35, 94, 154);
    let green = RGBColor(20, 124, 89);
    area.draw(&Text::new(
        "Pad compression under a steady 3 N squeeze",
        (22, 16),
        ("sans-serif", 26).into_font().color(&ink),
    ))?;
    area.draw(&Text::new(
        "Mean overlap of the two pad faces with the parcel, measured in the recorded poses",
        (23, 50),
        ("sans-serif", 15).into_font().color(&gray),
    ))?;
    let area = area.margin(75, 9, 14, 26);
    let mut chart = ChartBuilder::on(&area)
        .margin(4)
        .set_label_area_size(LabelAreaPosition::Left, 67)
        .set_label_area_size(LabelAreaPosition::Bottom, 47)
        .build_cartesian_2d(0f64..20f64, 0f64..1.68f64)?;
    chart
        .configure_mesh()
        .x_labels(6)
        .max_light_lines(0)
        .y_labels(6)
        .x_desc("Hold time (s)")
        .y_desc("Overlap per pad (mm)")
        .axis_desc_style(("sans-serif", 16).into_font().color(&ink))
        .label_style(("sans-serif", 13).into_font().color(&gray))
        .light_line_style(RGBColor(238, 241, 244))
        .bold_line_style(RGBColor(215, 220, 226))
        .draw()?;
    for (run, color) in [(&control, blue), (&authored, green)] {
        chart.draw_series(LineSeries::new(
            run.iter()
                .map(|p| (p.seconds, 0.5 * (p.compression_mm[0] + p.compression_mm[1]))),
            color.stroke_width(3),
        ))?;
    }
    let average = |a: [f64; 2]| (a[0] + a[1]) / 2.;
    chart.draw_series([Text::new(
        format!("Default    {:.3} mm", average(last(&control))),
        (14.0, 1.63),
        ("sans-serif", 17).into_font().color(&blue),
    )])?;
    chart.draw_series([Text::new(
        format!("30,000 N/m    {:.3} mm", average(last(&authored))),
        (13.3, 0.32),
        ("sans-serif", 17).into_font().color(&green),
    )])?;
    area.present()?;
    Ok(())
}
