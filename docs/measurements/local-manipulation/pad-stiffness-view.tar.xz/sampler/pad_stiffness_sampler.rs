// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Read native link states directly at the physical times used in the viewer.
use gz_physics::PhysicsBackend;
use gz_sim_core::{EntityId, Simulation};
use gz_sim_scene::{BodyHandle, Name, PhysicsEngine, load_world_with_sdf_step, set_joint_force};
use serde_json::{Value, json};
use std::{error::Error, io::Write};

const LINKS: [(&str, &str); 4] = [
    ("wrist", "default::gripper::wrist"),
    ("left", "default::gripper::left"),
    ("right", "default::gripper::right"),
    ("parcel", "default::parcel::body"),
];

fn record(sim: &Simulation, tick: u64) -> Result<Value, Box<dyn Error>> {
    let engine = sim.world().resource::<PhysicsBackend>();
    let mut poses = serde_json::Map::new();
    for (short, scoped) in LINKS {
        #[allow(deprecated)]
        let handle = sim
            .world()
            .iter_entities()
            .find(|e| e.get::<Name>().is_some_and(|n| n.0 == scoped))
            .and_then(|e| e.get::<BodyHandle>())
            .ok_or("missing link")?;
        let state = engine.state(handle.id()).ok_or("missing body state")?;
        poses.insert(
            short.into(),
            json!({"translation":state.position,"rotation":state.orientation}),
        );
    }
    Ok(json!({"time_ns": tick * 100_000, "poses": poses}))
}

fn main() -> Result<(), Box<dyn Error>> {
    let [world, schedule]: [String; 2] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected WORLD and hold or release")?;
    let (stride, commands): (u64, &[(f64, u64)]) = match schedule.as_str() {
        "hold" => (2500, &[(3., 200000)]),
        "release" => (10, &[(3., 500), (1.5, 1100), (-3., 800), (3., 500)]),
        _ => return Err("unknown schedule".into()),
    };
    let xml = std::fs::read_to_string(&world)?;
    let mut sim = load_world_with_sdf_step(
        &xml,
        &world,
        "default",
        &sdformat::NoResources,
        PhysicsEngine::MultiFidelity,
    )?;
    if sim.step_duration().as_nanos() != 100_000 {
        return Err("expected a 100 microsecond step".into());
    }
    let mut motors = vec![];
    for name in [
        "default::gripper::left_slide",
        "default::gripper::right_slide",
    ] {
        #[allow(deprecated)]
        let entity = sim
            .world()
            .iter_entities()
            .find(|e| e.get::<Name>().is_some_and(|n| n.0 == name))
            .ok_or("missing slider")?;
        motors.push(entity.get::<EntityId>().ok_or("missing entity id")?.get());
    }
    let mut poses = vec![record(&sim, 0)?];
    let mut tick = 0;
    for &(force, count) in commands {
        for &id in &motors {
            set_joint_force(&mut sim, id, force)?;
        }
        for _ in 0..count / stride {
            sim.step_exact(stride)?;
            tick += stride;
            poses.push(record(&sim, tick)?);
        }
    }
    std::io::stdout()
        .lock()
        .write_all(&serde_json::to_vec(&poses)?)?;
    Ok(())
}
