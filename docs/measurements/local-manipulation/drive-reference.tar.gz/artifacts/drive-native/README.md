# Drive trajectory against Gazebo DART

The force-limited Rust velocity servo with `--sdf-default-friction` passed all six comparison thresholds over the 551 matched samples. Both vehicles reached the stopping criterion 0.39 s after the brake command. They traveled 61.395 mm (DART) and 61.414 mm (Rust) during braking.

| Measured difference | Soft motor | Servo, Rapier friction | Servo, SDF friction | Limit |
| --- | ---: | ---: | ---: | ---: |
| Maximum chassis horizontal displacement error (m) | 1.58102 | 0.080494 | 0.000316 | 0.10 |
| Maximum chassis heading error (rad) | 1.46711 | 0.088013 | 0.000403 | 0.10 |
| Maximum left wheel angle error (rad) | 2.57917 | 0.000635 | 0.000647 | 0.15 |
| Maximum right wheel angle error (rad) | 6.74250 | 0.003442 | 0.003456 | 0.15 |
| Braking distance error (m) | 0.130411 | 0.043949 | 0.000020 | 0.03 |
| Maximum lateral axle speed error (m/s) | 0.000143 | 0.043468 | 0.000100 | 0.05 |

Each run used the same unmodified upstream world, 1 ms physics clock, command stream and 10 ms observation grid. The comparison measures actual chassis and axle motion during settling, straight drive, a left turn and braking. The source procedure in `tools/physics-audit/drive-native/README.md` defines the command timings, intermediate tolerances and units. The three Rust binary identities are in `replay-profiles.json`.

| CSV | Comparison |
| --- | --- |
| `native.csv` | `native-metrics.json` |
| `rust-soft.csv` | `comparison-initial.json` |
| `rust-servo.csv` | `comparison-servo.json` |
| `rust-sdf-friction.csv` | `comparison.json` |

`drive-reference.tar.gz` contains these files, the original inputs, provenance and Rust check program. Extract into a new directory, then verify evidence contents with `sha256sum -c artifacts/drive-native/traces.sha256`. The separate native library checksum manifest includes paths specific to the capture host.
