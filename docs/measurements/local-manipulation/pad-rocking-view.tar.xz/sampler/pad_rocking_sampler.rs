// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Replay the experiment through the Bevy input API and inspect native link poses and pad reactions.
use glam::{DQuat, DVec3};
use gz_physics::{BodyId, PhysicsBackend};
use gz_physics_multifidelity::MultiFidelityBackend;
use gz_sim_core::{EntityId, Simulation};
use gz_sim_scene::{
    BodyHandle, Name, PhysicsEngine, load_world_with_sdf_step, queue_link_world_wrench,
    set_joint_force,
};
use serde_json::{Value, json};
use std::collections::BTreeMap;
use std::error::Error;
use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::PathBuf;

type Result<T> = std::result::Result<T, Box<dyn Error>>;

struct Links {
    ids: BTreeMap<String, u64>,
    bodies: BTreeMap<String, BodyId>,
    pads: [BodyId; 2],
    parcel: BodyId,
}

impl Links {
    fn read(sim: &Simulation) -> Result<Self> {
        let mut ids = BTreeMap::new();
        let mut bodies = BTreeMap::new();
        #[allow(deprecated)]
        for entity in sim.world().iter_entities() {
            if let (Some(id), Some(name)) = (entity.get::<EntityId>(), entity.get::<Name>()) {
                ids.insert(name.0.clone(), id.get());
                if let Some(body) = entity.get::<BodyHandle>() {
                    bodies.insert(name.0.clone(), body.id());
                }
            }
        }
        let pads = [
            bodies["default::gripper::left"],
            bodies["default::gripper::right"],
        ];
        let parcel = bodies["default::parcel::body"];
        Ok(Self {
            ids,
            bodies,
            pads,
            parcel,
        })
    }

    fn poses(&self, engine: &PhysicsBackend, time_ns: u64) -> Result<Value> {
        let mut poses = serde_json::Map::new();
        for (name, id) in &self.bodies {
            let s = engine.state(*id).ok_or("missing native state")?;
            poses.insert(
                name.clone(),
                json!({"translation":s.position, "rotation":s.orientation}),
            );
        }
        Ok(json!({"time_ns":time_ns, "poses":poses}))
    }

    fn reaction(&self, engine: &PhysicsBackend, dt: f64, time_ns: u64) -> Result<Value> {
        let native = engine
            .downcast_ref::<MultiFidelityBackend>()
            .ok_or("expected local physics")?;
        let mut count = [0_u32; 2];
        let mut selected = [0_usize; 2];
        let mut normal = [0.0; 2];
        let mut moment = [DVec3::ZERO; 2];
        for patch in native.rigid_contact_patches() {
            let (other, on_a) = if patch.a == self.parcel {
                (patch.b, true)
            } else if patch.b == self.parcel {
                (patch.a, false)
            } else {
                continue;
            };
            let Some(side) = self.pads.iter().position(|p| *p == other) else {
                continue;
            };
            selected[side] += patch.points.len();
            for p in patch.points {
                if p.normal_impulse > 0.0 {
                    count[side] += 1;
                }
                normal[side] += p.normal_impulse / dt;
                let n = DVec3::from(patch.normal_on_a) * p.normal_impulse;
                let shear = DVec3::from(p.tangent_impulse_on_a.ok_or("missing pad shear impulse")?);
                let (arm, impulse) = if on_a {
                    (p.lever_a, n + shear)
                } else {
                    (p.lever_b, -n - shear)
                };
                moment[side] += DVec3::from(arm).cross(impulse) / dt;
            }
        }
        let state = engine.state(self.parcel).ok_or("missing parcel")?;
        let q = DQuat::from_array(state.orientation);
        let pitch_deg = -(q * DVec3::X).z.clamp(-1., 1.).asin().to_degrees();
        Ok(
            json!({"time_ns":time_ns, "pitch_deg":pitch_deg, "normal_n":normal,
            "moment_nm":moment.map(|m|m.to_array()), "loaded_points":count, "selected_points":selected}),
        )
    }
}

fn main() -> Result<()> {
    let mut args = std::env::args().skip(1);
    let world = args.next().ok_or("expected WORLD JOURNAL STRIDE OUT")?;
    let journal: Value = serde_json::from_slice(&fs::read(args.next().ok_or("journal")?)?)?;
    let stride: u64 = args.next().ok_or("stride")?.parse()?;
    if stride == 0 {
        return Err("stride must be positive".into());
    }
    let dir = PathBuf::from(args.next().ok_or("output")?);
    fs::create_dir_all(&dir)?;
    let mut sim = load_world_with_sdf_step(
        &fs::read_to_string(&world)?,
        &world,
        "default",
        &sdformat::NoResources,
        PhysicsEngine::MultiFidelity,
    )?;
    let links = Links::read(&sim)?;
    let step_ns = u64::try_from(sim.step_duration().as_nanos())?;
    let dt = sim.step_duration().as_secs_f64();
    let mut poses = vec![links.poses(sim.world().resource(), 0)?];
    let mut loads = BufWriter::new(File::create(dir.join("loads.jsonl"))?);
    let mut tick = 0;
    for cmd in journal["commands"].as_array().ok_or("commands")? {
        match cmd["op"].as_str().ok_or("op")? {
            "step" => {
                for _ in 0..cmd["count"].as_u64().ok_or("count")? {
                    sim.step_exact(1)?;
                    tick += 1;
                    let time_ns = tick * step_ns;
                    let engine = sim.world().resource::<PhysicsBackend>();
                    writeln!(loads, "{}", links.reaction(engine, dt, time_ns)?)?;
                    if tick.is_multiple_of(stride) {
                        poses.push(links.poses(engine, time_ns)?);
                    }
                }
            }
            "set_joint_force" => set_joint_force(
                &mut sim,
                links.ids[cmd["joint"].as_str().ok_or("joint")?],
                cmd["force"].as_f64().ok_or("force")?,
            )?,
            "wrench" => queue_link_world_wrench(
                &mut sim,
                links.ids[cmd["link"].as_str().ok_or("link")?],
                serde_json::from_value(cmd["force"].clone())?,
                serde_json::from_value(cmd["torque"].clone())?,
            )?,
            op => return Err(format!("unexpected operation {op}").into()),
        }
    }
    loads.flush()?;
    fs::write(dir.join("poses.json"), serde_json::to_vec(&poses)?)?;
    Ok(())
}
