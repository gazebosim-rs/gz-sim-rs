// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Plot independent native contact-wrench samples and their pose clocks.
use plotters::prelude::*;
use serde_json::{Value, json};
use std::{
    error::Error,
    fs::File,
    io::{BufRead, BufReader},
    path::Path,
};

type Result<T> = std::result::Result<T, Box<dyn Error>>;

#[derive(Clone, Copy)]
struct Point {
    ms: f64,
    degrees: f64,
    torque: f64,
    counts: [u64; 2],
    loads: [f64; 2],
}

fn read(path: &Path) -> Result<Vec<Point>> {
    let mut points = Vec::new();
    for line in BufReader::new(File::open(path)?).lines() {
        let v: Value = serde_json::from_str(&line?)?;
        let moments: [[f64; 3]; 2] = serde_json::from_value(v["moment_nm"].clone())?;
        points.push(Point {
            ms: v["time_ns"].as_u64().ok_or("time")? as f64 * 1e-6,
            degrees: v["pitch_deg"].as_f64().ok_or("pitch")?,
            torque: moments[0][1] + moments[1][1],
            counts: serde_json::from_value(v["loaded_points"].clone())?,
            loads: serde_json::from_value(v["normal_n"].clone())?,
        });
    }
    Ok(points)
}

fn reacquisition(run: &[Point]) -> Result<f64> {
    let mut edge = false;
    for p in run.iter().filter(|p| p.ms > 201.0) {
        if p.counts == [2; 2] {
            edge = true;
        }
        if edge && p.counts[0] > 2 && p.counts[1] > 2 {
            return Ok(p.ms);
        }
    }
    Err("no bilateral face reacquisition".into())
}

fn main() -> Result<()> {
    let [fine, coarse, plot, out]: [String; 4] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected FINE-LOADS COARSE-LOADS SVG SUMMARY")?;
    let runs = [read(Path::new(&fine))?, read(Path::new(&coarse))?];
    let early = reacquisition(&runs[0])?.min(reacquisition(&runs[1])?);
    let late = reacquisition(&runs[0])?.max(reacquisition(&runs[1])?);
    let start = (early - 0.30).floor();
    let end = (late + 0.80).ceil();
    let canvas = SVGBackend::new(&plot, (810, 600)).into_drawing_area();
    canvas.fill(&WHITE)?;
    let ink = RGBColor(36, 48, 61);
    let fine_color = RGBColor(12, 109, 116);
    let coarse_color = RGBColor(174, 71, 25);
    canvas.draw(&Text::new(
        "Rocking a block between gripper pads",
        (18, 32),
        ("sans-serif", 27).into_font().color(&ink),
    ))?;
    canvas.draw(&Text::new(
        "Contact torque on the block about its center of mass",
        (18, 60),
        ("sans-serif", 16).into_font().color(&ink),
    ))?;
    for (i, color) in [fine_color, coarse_color].iter().enumerate() {
        let x = 32 + i as i32 * 186;
        canvas.draw(&PathElement::new(
            vec![(x, 86), (x + 30, 86)],
            color.stroke_width(3),
        ))?;
        canvas.draw(&Text::new(
            if i == 0 {
                "Fine   5 µs"
            } else {
                "Coarse   100 µs"
            },
            (x + 40, 90),
            ("sans-serif", 14).into_font().color(&ink),
        ))?;
    }
    let (_, lower) = canvas.split_vertically(100);
    let panels = lower.split_evenly((2, 1));
    let max_torque = runs
        .iter()
        .flat_map(|r| r.iter())
        .filter(|p| (start..=end).contains(&p.ms))
        .map(|p| p.torque.abs())
        .fold(0., f64::max)
        .ceil()
        .max(1.);
    let step = (end - start) / 8.;
    for (i, panel) in panels.iter().enumerate() {
        let (x0, x1, y0, y1, y_label) = if i == 0 {
            (195.0, 260.0, -2., 16., "Block tilt (degrees)")
        } else {
            (
                start,
                end,
                -0.1 * max_torque,
                max_torque,
                "Return torque (N·m)",
            )
        };
        let mut chart = ChartBuilder::on(panel)
            .margin_right(18)
            .margin_top(8)
            .margin_left(8)
            .margin_bottom(5)
            .x_label_area_size(40)
            .y_label_area_size(62)
            .build_cartesian_2d(x0..x1, y0..y1)?;
        chart
            .configure_mesh()
            .x_desc(if i == 0 {
                "Time (ms)"
            } else {
                "Time at return to face (ms)"
            })
            .y_desc(y_label)
            .label_style(("sans-serif", 13).into_font().color(&ink))
            .axis_desc_style(("sans-serif", 14).into_font().color(&ink))
            .light_line_style(RGBColor(243, 245, 247))
            .bold_line_style(RGBColor(220, 225, 231))
            .x_labels(7)
            .y_labels(5)
            .draw()?;
        for (j, run) in runs.iter().enumerate() {
            let interval = run.iter().filter(|p| (x0..=x1).contains(&p.ms));
            let sample = |p: &Point| (p.ms, if i == 0 { p.degrees } else { p.torque });
            if j == 0 {
                let stride = if i == 0 { 10 } else { 1 };
                chart.draw_series(LineSeries::new(
                    interval.step_by(stride).map(sample),
                    fine_color.stroke_width(3),
                ))?;
            } else {
                if i == 1 {
                    chart.draw_series(LineSeries::new(
                        interval.clone().map(sample),
                        coarse_color.stroke_width(1),
                    ))?;
                }
                chart.draw_series(interval.step_by(if i == 0 { 20 } else { 1 }).map(|p| {
                    Circle::new(
                        sample(p),
                        if i == 0 { 3 } else { 4 },
                        coarse_color.stroke_width(2),
                    )
                }))?;
            }
        }
        if i == 1 {
            let t = reacquisition(&runs[0])?;
            chart.draw_series(std::iter::once(PathElement::new(
                vec![(t, y0), (t, max_torque * 0.91)],
                RGBColor(100, 115, 125).stroke_width(1),
            )))?;
            chart.draw_series(std::iter::once(Text::new(
                "First returning face contacts",
                (t + step / 3., max_torque * 0.91),
                ("sans-serif", 13).into_font().color(&ink),
            )))?;
        }
    }
    canvas.present()?;
    let mut table = Vec::new();
    for run in &runs {
        let peak = run
            .iter()
            .max_by(|a, b| a.degrees.total_cmp(&b.degrees))
            .ok_or("no data")?;
        let ret = run.iter().filter(|p| (start..=end).contains(&p.ms));
        table.push(json!({"peak_angle_deg":peak.degrees, "peak_time_ms":peak.ms, "points_at_peak":peak.counts,
            "first_return_ms":reacquisition(run)?, "peak_return_normal_n":ret.clone().flat_map(|p|p.loads).fold(0.,f64::max),
            "peak_return_torque_nm":ret.map(|p|p.torque.abs()).fold(0.,f64::max),
            "last_loaded_points":run.last().ok_or("empty")?.counts}));
    }
    std::fs::write(out, serde_json::to_vec_pretty(&table)?)?;
    Ok(())
}
