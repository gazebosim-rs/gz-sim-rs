// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Run with the compact or tall rocking SDF, and the corresponding pulse torque in N m.
use gz_sim_core::EntityId;
use gz_sim_scene::{
    Name, PhysicsEngine, load_world_with_sdf_step, queue_link_world_wrench, set_joint_force,
};
use std::time::Instant;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut args = std::env::args().skip(1);
    let path = args.next().ok_or("expected SDF path and pulse torque")?;
    let torque: f64 = args.next().ok_or("missing pulse torque")?.parse()?;
    let mut sim = load_world_with_sdf_step(
        &std::fs::read_to_string(&path)?,
        &path,
        "default",
        &sdformat::NoResources,
        PhysicsEngine::MultiFidelity,
    )?;
    let named = |name: &str| {
        #[allow(deprecated)]
        sim.world()
            .iter_entities()
            .find(|e| e.get::<Name>().is_some_and(|n| n.0 == name))
            .unwrap()
            .get::<EntityId>()
            .unwrap()
            .get()
    };
    let pads = [
        named("default::gripper::left_slide"),
        named("default::gripper::right_slide"),
    ];
    let parcel = named("default::parcel::body");
    for pad in pads {
        set_joint_force(&mut sim, pad, 3.0)?;
    }
    let dt_us = u64::try_from(sim.step_duration().as_micros())?;
    assert_eq!(dt_us, 100);
    sim.step_exact(200_000 / dt_us)?;
    let mut times = Vec::with_capacity(2500);
    for tick in 0..2500 {
        if tick * dt_us < 200 {
            queue_link_world_wrench(&mut sim, parcel, [0.0; 3], [0.0, torque, 0.0])?;
        }
        let clock = Instant::now();
        sim.step_exact(1)?;
        times.push(clock.elapsed().as_nanos());
    }
    // The first 60 ms includes the outbound edge and the beginning of the return.
    for (name, samples) in [("motion", &times[..600]), ("full", &times[..])] {
        let mut sorted = samples.to_vec();
        sorted.sort_unstable();
        println!(
            "{name} {} {} {}",
            sorted[sorted.len() / 2 - 1],
            sorted[sorted.len() * 95 / 100 - 1],
            sorted[sorted.len() * 99 / 100 - 1]
        );
    }
    Ok(())
}
