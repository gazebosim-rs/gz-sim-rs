// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Plot the sensed parcel motion and verify it against the actual replay poses.
use plotters::{coord::Shift, prelude::*};
use serde_json::{Value, json};
use std::{
    collections::BTreeMap,
    error::Error,
    fs::{self, File},
    io::{BufRead, BufReader},
    path::Path,
};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
type Area<'a> = DrawingArea<SVGBackend<'a>, Shift>;
const INK: RGBColor = RGBColor(31, 49, 61);
const SUB: RGBColor = RGBColor(74, 94, 107);
const GRID: RGBColor = RGBColor(219, 227, 231);
const TEAL: RGBColor = RGBColor(0, 111, 100);
const ORANGE: RGBColor = RGBColor(175, 78, 35);
const CASES: [(&str, &str); 14] = [
    ("hold", "Strong grip"),
    ("open", "Weak grip, feedback off"),
    ("catch", "Slip feedback on"),
    ("delayed", "Slower sensing"),
    ("slow", "Slower fingers"),
    ("limited", "Limited finger force"),
    ("unload", "Back off the lift"),
    ("heavy", "Heavier parcel"),
    ("slick", "Lower friction"),
    ("mirror", "Weight on the left"),
    ("repeat", "Second disturbance"),
    ("release", "Intentional release"),
    ("delayed-unload", "Back off lift, slower sensing"),
    ("tactile", "Sense slip at the contacts"),
];

fn rows(path: &Path) -> Result<Vec<Value>> {
    BufReader::new(File::open(path)?)
        .lines()
        .map(|line| Ok(serde_json::from_str(&line?)?))
        .collect()
}
fn number(v: &Value) -> Result<f64> {
    v.as_f64().ok_or_else(|| "missing numeric field".into())
}
fn ns(v: &Value) -> Result<u64> {
    v.as_u64().ok_or_else(|| "missing clock".into())
}

struct Run {
    slip: Vec<(f64, f64)>,
    force: Vec<(f64, f64)>,
    frames: usize,
    max_pose_diff: f64,
    tactile_peak_error_um: Option<f64>,
}
fn read(root: &Path, name: &str) -> Result<Run> {
    let dir = root.join(name);
    let ticks = rows(&dir.join("ticks.jsonl"))?;
    let mut slip = Vec::new();
    let mut force = Vec::new();
    let mut tactile_peak_error_um: Option<f64> = None;
    let mut z = BTreeMap::new();
    for t in &ticks {
        let clock = ns(&t["time_ns"])?;
        if z.insert(
            clock,
            (number(&t["pad_z_m"])?, number(&t["parcel_com_z_m"])?),
        )
        .is_some()
        {
            return Err("duplicate public tick".into());
        }
        if clock >= 210_000_000 {
            let ms = clock as f64 / 1e6;
            slip.push((ms, 1000. * number(&t["slip_m"])?));
            if name.starts_with("tactile-") {
                let difference_um =
                    1e6 * (number(&t["tactile_height_m"])? + number(&t["slip_m"])?).abs();
                tactile_peak_error_um =
                    Some(tactile_peak_error_um.unwrap_or_default().max(difference_um));
            }
            force.push((ms, number(&t["force_n"])?));
        }
    }
    let archive = rows(&dir.join("epoch-0/frames.jsonl"))?;
    let visual = |scene: &Value, name: &str| -> Result<Value> {
        let visuals = scene["visuals"].as_array().ok_or("missing visuals")?;
        Ok(visuals
            .iter()
            .find(|v| v["name"] == name)
            .ok_or("missing named visual")?
            .clone())
    };
    let mut frames = 0;
    let mut max_pose_diff: f64 = 0.;
    for frame in &archive {
        if frame["kind"] != "frame" {
            continue;
        }
        let scene: Value = serde_json::from_str(frame["scene"].as_str().ok_or("scene")?)?;
        let clock = ns(&scene["seconds"])? * 1_000_000_000 + ns(&scene["nanoseconds"])?;
        if clock != (frames as u64) * 1_000_000 {
            return Err("recording cadence differs".into());
        }
        frames += 1;
        if clock == 0 {
            continue;
        }
        let (pad_z, parcel_z) = z.get(&clock).ok_or("tick missing at frame clock")?;
        let left = visual(&scene, "default::gripper::left::pad")?;
        let right = visual(&scene, "default::gripper::right::pad")?;
        let parcel = visual(&scene, "default::parcel::body::block")?;
        let pad = 0.5 * (number(&left["translation"][2])? + number(&right["translation"][2])?);
        let q = &parcel["rotation"];
        let offset = if name.starts_with("mirror-") {
            -0.0045
        } else {
            0.0045
        };
        let com = number(&parcel["translation"][2])?
            + offset * 2. * (number(&q[0])? * number(&q[2])? - number(&q[3])? * number(&q[1])?);
        max_pose_diff = max_pose_diff
            .max((pad - pad_z).abs())
            .max((com - parcel_z).abs());
        if max_pose_diff > 1e-12 {
            return Err(format!(
                "{name}: replay differs from sensed coordinates at {clock} ns ({max_pose_diff:e} m)"
            )
            .into());
        }
    }
    if slip.is_empty() || frames == 0 {
        return Err("empty run".into());
    }
    Ok(Run {
        slip,
        force,
        frames,
        max_pose_diff,
        tactile_peak_error_um,
    })
}

fn label(area: &Area, x: i32, y: i32, size: u32, color: RGBColor, text: &str) -> Result<()> {
    area.draw(&Text::new(
        text,
        (x, y),
        ("sans-serif", size).into_font().color(&color),
    ))?;
    Ok(())
}

fn main() -> Result<()> {
    let [root, svg, report]: [String; 3] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected RUN_DIRECTORY PLOT.svg METRICS.json")?;
    let root = Path::new(&root);
    let mut runs = BTreeMap::new();
    let mut measurements = BTreeMap::new();
    for (name, _) in CASES {
        let adaptive = read(root, &format!("{name}-adaptive"))?;
        let fine = read(root, &format!("{name}-fine"))?;
        if adaptive.slip.len() != fine.slip.len() {
            return Err("public clocks differ".into());
        }
        let mut max_slip_diff: f64 = 0.;
        for ((time, a), (other, f)) in adaptive.slip.iter().zip(&fine.slip) {
            if time != other {
                return Err("unmatched field time".into());
            }
            max_slip_diff = max_slip_diff.max((a - f).abs());
        }
        measurements.insert(name,json!({
            "end_ms":adaptive.slip.last().unwrap().0,"terminal_adaptive_slip_mm":adaptive.slip.last().unwrap().1,
            "terminal_fine_slip_mm":fine.slip.last().unwrap().1,"max_trajectory_difference_mm":max_slip_diff,
            "adaptive_contact_sensor_max_displacement_error_um":adaptive.tactile_peak_error_um,
            "fine_contact_sensor_max_displacement_error_um":fine.tactile_peak_error_um,
            "frames_adaptive":adaptive.frames,"frames_fine":fine.frames,
            "max_archived_height_difference_from_native_ticks_m":adaptive.max_pose_diff.max(fine.max_pose_diff),
        }));
        runs.insert(name, (adaptive, fine));
    }
    let mut text = String::new();
    {
        let root = SVGBackend::with_string(&mut text, (1320, 1258)).into_drawing_area();
        root.fill(&WHITE)?;
        label(
            &root,
            28,
            20,
            32,
            INK,
            "Catching a slipping parcel during a lift",
        )?;
        label(
            &root,
            28,
            70,
            18,
            SUB,
            "A weakened grip at 210 ms triggers a race between downward slip and the fingers’ response.",
        )?;
        label(&root, 28, 123, 22, INK, "Finger response to the first slip")?;
        let panel = root.clone().shrink((18, 165), (588, 215));
        let mut chart = ChartBuilder::on(&panel)
            .margin(3)
            .margin_right(15)
            .x_label_area_size(40)
            .y_label_area_size(53)
            .build_cartesian_2d(210_f64..290_f64, 0_f64..6_f64)?;
        chart
            .configure_mesh()
            .x_desc("Time (ms)")
            .y_desc("Force per finger (N)")
            .x_labels(5)
            .y_labels(4)
            .label_style(("sans-serif", 13))
            .axis_desc_style(("sans-serif", 14))
            .max_light_lines(0)
            .bold_line_style(GRID)
            .draw()?;
        for (name, color) in [("catch", TEAL), ("open", ORANGE)] {
            let points = runs[name]
                .0
                .force
                .iter()
                .filter(|(t, _)| *t <= 290.)
                .copied();
            chart.draw_series(LineSeries::new(points, color.stroke_width(3)))?;
        }
        for (x, title, color) in [
            (55, "Slip feedback on", TEAL),
            (291, "Weak grip, feedback off", ORANGE),
        ] {
            root.draw(&PathElement::new(
                [(x, 406), (x + 29, 406)],
                color.stroke_width(3),
            ))?;
            label(&root, x + 38, 397, 16, INK, title)?;
        }
        label(&root, 637, 123, 22, INK, "gz-web-rs at 290 ms")?;
        label(&root, 637, 377, 17, INK, "Slip feedback on")?;
        label(&root, 979, 377, 17, INK, "Weak grip, feedback off")?;
        label(
            &root,
            28,
            458,
            23,
            INK,
            "Parcel drop relative to the pads (mm)",
        )?;
        label(
            &root,
            28,
            493,
            16,
            SUB,
            "Each panel shows the full run after 210 ms on its own scale. Lines show adaptive physics; dots show continuous 1 µs physics.",
        )?;
        for (i, (name, title)) in CASES.iter().enumerate() {
            let (adaptive, fine) = &runs[name];
            let x = (i % 4) * 324 + 17;
            let y = (i / 4) * 174 + 538;
            let end = *adaptive.slip.last().ok_or("empty slip curve")?;
            let y_max = adaptive
                .slip
                .iter()
                .chain(&fine.slip)
                .map(|p| p.1)
                .fold(0., f64::max);
            let ymax = (y_max * 1.10).max(0.2);
            let ymin = adaptive
                .slip
                .iter()
                .chain(&fine.slip)
                .map(|p| p.1)
                .fold(0., f64::min);
            label(&root, (x + 8) as i32, y as i32, 17, INK, title)?;
            let panel = root.clone().shrink((x as u32, (y + 23) as u32), (310, 138));
            let mut chart = ChartBuilder::on(&panel)
                .margin_top(9)
                .margin_right(15)
                .x_label_area_size(28)
                .y_label_area_size(48)
                .build_cartesian_2d(210_f64..end.0, (ymin - ymax * 0.05)..ymax)?;
            chart
                .configure_mesh()
                .max_light_lines(0)
                .x_labels(4)
                .y_labels(3)
                .label_style(("sans-serif", 12))
                .bold_line_style(GRID)
                .y_label_formatter(&|n| {
                    if ymax < 1. {
                        format!("{n:.2}")
                    } else if ymax < 10. {
                        format!("{n:.1}")
                    } else {
                        format!("{n:.0}")
                    }
                })
                .draw()?;
            chart.draw_series(LineSeries::new(
                adaptive.slip.iter().copied(),
                TEAL.stroke_width(2),
            ))?;
            let stride = (fine.slip.len() / 10).max(1);
            chart.draw_series(
                fine.slip
                    .iter()
                    .skip(stride / 2)
                    .step_by(stride)
                    .map(|p| Circle::new(*p, 3, ORANGE.filled())),
            )?;
        }
        label(
            &root,
            28,
            1234,
            15,
            SUB,
            "Horizontal axes show simulation time in milliseconds. Positive drop means the parcel moved downward relative to the fingers.",
        )?;
        let free = runs["open"].0.slip.last().unwrap().1;
        let guarded = runs["catch"].0.slip.last().unwrap().1;
        label(&root, 694, 1080, 20, INK, "80 ms after the grip weakened")?;
        label(
            &root,
            694,
            1120,
            17,
            SUB,
            &format!(
                "With feedback, the parcel settled {:.3} mm lower in the pads.",
                guarded
            ),
        )?;
        label(
            &root,
            694,
            1150,
            17,
            SUB,
            &format!(
                "With feedback disabled, it had slipped {:.2} mm and was still moving.",
                free
            ),
        )?;
        let tactile_error = runs["tactile"]
            .0
            .tactile_peak_error_um
            .ok_or("missing tactile measurement")?;
        label(
            &root,
            694,
            1180,
            17,
            SUB,
            &format!("Contact sensing tracked the parcel’s drop to within {tactile_error:.2} µm."),
        )?;
        root.present()?;
    }
    let mut images = String::new();
    for (name, x) in [("catch", 637), ("open", 979)] {
        let jpg = format!("{name}-adaptive/comparison.jpg");
        if !root.join(&jpg).is_file() {
            return Err(format!("missing {jpg}").into());
        }
        images.push_str(&format!(r##"<defs><clipPath id="{name}"><rect x="{x}" y="165" width="319" height="194"/></clipPath></defs><g clip-path="url(#{name})"><image xmlns:xlink="http://www.w3.org/1999/xlink" transform="translate({x},165) scale(0.48) translate(-388,-242)" width="1440" height="900" xlink:href="{jpg}"/></g>"##));
    }
    text.insert_str(text.rfind("</svg>").ok_or("invalid SVG")?, &images);
    fs::write(svg, text)?;
    fs::write(report, serde_json::to_vec_pretty(&measurements)?)?;
    Ok(())
}
