// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0

use bevy_ecs::prelude::Entity;
use gz_physics::{BodyId, BodyState, PhysicsBackend};
use gz_physics_multifidelity::MultiFidelityBackend;
use gz_sim_core::{EntityId, Simulation};
use gz_sim_scene::{BodyHandle, JointSample, Name, PhysicsEngine, load_world_with_sdf_step, set_joint_force};

const WORLD: &str = include_str!("../../../examples/worlds/local_two_finger_load.sdf");
const DT: f64 = 0.0001;
const MASS: f64 = 0.2;
const GRAVITY: f64 = 9.81;

fn named(sim: &Simulation, name: &str) -> Entity {
    #[allow(deprecated)]
    sim.world().iter_entities().find(|e| e.get::<Name>().is_some_and(|value| value.0 == name)).unwrap().id()
}

struct Rig {
    sim: Simulation,
    slides: [Entity; 2],
    pads: [BodyId; 2],
    parcel: BodyId,
}

impl Rig {
    fn new(dt: f64) -> Self {
        let sdf = WORLD.replace(">0.0001<", &format!(">{dt}<"));
        let sim = load_world_with_sdf_step(&sdf,"two-finger-load.sdf","default",&sdformat::NoResources,PhysicsEngine::MultiFidelity).unwrap();
        let get_body = |name| sim.world().get::<BodyHandle>(named(&sim,name)).unwrap().id();
        let parcel = get_body("default::parcel::body");
        let pads = [get_body("default::gripper::left"),get_body("default::gripper::right")];
        let slides = [named(&sim,"default::gripper::left_slide"),named(&sim,"default::gripper::right_slide")];
        Self {sim, slides, pads, parcel}
    }
    fn drive(&mut self, force: [f64;2]) {
        for (slide, f) in self.slides.into_iter().zip(force) {
            let id = self.sim.world().get::<EntityId>(slide).unwrap().get();
            set_joint_force(&mut self.sim,id,f).unwrap();
        }
    }
    fn state(&self) -> BodyState {self.sim.world().resource::<PhysicsBackend>().state(self.parcel).unwrap()}
    fn travel(&self) -> [f64;2] {self.slides.map(|s|self.sim.world().get::<JointSample>(s).unwrap().state.position)}
    fn read(&self) -> ([f64;2],[f64;2]) {
        let engine=self.sim.world().resource::<PhysicsBackend>().downcast_ref::<MultiFidelityBackend>().unwrap();
        let mut n=[0.;2];let mut t=[0.;2];
        for p in engine.rigid_contact_patches() {
            let (pad, sign)=if p.a==self.parcel {(p.b,1.)}else if p.b==self.parcel {(p.a,-1.)}else {panic!("Unexpected non-parcel contact")};
            let i=self.pads.iter().position(|id|*id==pad).unwrap();
            for q in p.points { n[i]+=q.normal_impulse;t[i]+=q.tangent_impulse_on_a.unwrap()[2]*sign; }
        }
        (n,t)
    }
}

#[test]
fn probe() {
    for (dt, cases) in [(DT, vec![([3.,3.],500),([1.5,1.5],1100),([-3.,-3.],800),([3.,3.],500)]),
        (DT, vec![([3.,3.],500),([6.,2.5],1800),([2.5,6.],3000)])] {
        let mut rig=Rig::new(dt);
        let mut k=0;
        for (f,ticks) in cases {
            rig.drive(f);
            for _ in 0..ticks {
                k+=1;rig.sim.step_exact(1).unwrap();
                if k%100==0 || k==1 {let (n,t)=rig.read();let s=rig.state();println!("k={k} f={f:?} n={:?} t={:?} xz={:?} vxz={:?} wy={} q={:?}",n.map(|j|j/dt),t.map(|j|j/dt),[s.position[0],s.position[2]],[s.velocity[0],s.velocity[2]],s.angular_velocity[1],rig.travel());}
            }
        }
    }
}

#[test]
fn scratch_export() {
    use std::io::Write;
    let mut rig=Rig::new(DT);
    let mut f=std::fs::File::create(std::env::var("NATIVE_POSE_DUMP").unwrap()).unwrap();
    let names=["default::gripper::wrist","default::gripper::left","default::gripper::right","default::parcel::body"];
    let handles=names.map(|s| rig.sim.world().get::<BodyHandle>(named(&rig.sim,s)).unwrap().id());
    let mut k=0;
    let record=|r:&Rig, tick:usize, file:&mut std::fs::File| {
        let b=r.sim.world().resource::<PhysicsBackend>();
        let poses=handles.map(|id|{let s=b.state(id).unwrap();serde_json::json!({"translation":s.position,"rotation":s.orientation})});
        writeln!(file,"{}",serde_json::json!({"step":tick,"poses":poses})).unwrap();
    };
    record(&rig,0,&mut f);
    for (eff,n) in [([3.,3.],500),([1.5,1.5],1100),([-3.,-3.],800),([3.,3.],500)] {
        rig.drive(eff);
        for _ in 0..n {k+=1;rig.sim.step_exact(1).unwrap();if k%10==0 { record(&rig,k,&mut f); }}
    }
}
