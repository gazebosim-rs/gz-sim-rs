// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Plot measured normal force and the internal clock of the gripper impact.
use plotters::prelude::*;
use serde_json::{Value, json};
use std::{
    error::Error,
    fs::{self, File},
    io::{BufRead, BufReader},
    path::Path,
};

type Result<T> = std::result::Result<T, Box<dyn Error>>;

fn rows(dir: &Path, name: &str) -> Result<Vec<Value>> {
    BufReader::new(File::open(dir.join(name))?)
        .lines()
        .map(|l| Ok(serde_json::from_str(&l?)?))
        .collect()
}

struct Run {
    force: Vec<(f64, f64)>,
    ticks: Vec<(f64, u64)>,
    summary: Value,
}

fn read(dir: &Path) -> Result<Run> {
    let native = rows(dir, "native.jsonl")?;
    let public = rows(dir, "public.jsonl")?;
    let mut force = Vec::new();
    let mut first = None;
    for row in &native {
        let ns = row["time_ns"].as_u64().ok_or("native timestamp")?;
        if !(238_000_000..=240_000_000).contains(&ns) {
            continue;
        }
        let end = ns as f64 * 1e-6;
        let width = row["duration_ns"].as_u64().ok_or("native duration")? as f64 * 1e-6;
        let load = row["force_n"][0].as_f64().ok_or("left load")?;
        if row["loaded_points"][0].as_u64().ok_or("count")? > 2 && first.is_none() {
            first = Some(end);
        }
        force.extend_from_slice(&[(end - width, load), (end, load)]);
    }
    let mut impulse = [0.0; 2];
    let mut moment = [0.0; 2];
    let mut peak = [0.0; 2];
    let mut at = [0; 2];
    let mut ticks = Vec::new();
    let mut calls = 0;
    let mut refined = Vec::new();
    for (i, p) in public.iter().enumerate() {
        let ns = p["time_ns"].as_u64().ok_or("public timestamp")?;
        assert_eq!(ns, (i as u64 + 1) * 200_000);
        let n = p["native_calls"].as_u64().ok_or("native count")?;
        calls += n;
        if n > 1 {
            refined.push(ns);
        }
        ticks.push((ns as f64 * 1e-6, n));
        if ns <= 238_000_000 || ns > 240_000_000 {
            continue;
        }
        for side in 0..2 {
            impulse[side] += p["normal_impulse_ns"][side].as_f64().ok_or("impulse")?;
            moment[side] += p["angular_impulse_nms"][side]
                .as_f64()
                .ok_or("angular impulse")?;
            let f = p["peak_n"][side].as_f64().ok_or("peak")?;
            if f > peak[side] {
                peak[side] = f;
                at[side] = p["peak_time_ns"][side].as_u64().ok_or("peak time")?;
            }
        }
    }
    let t = first.ok_or("missing returning load")?;
    if public.len() != 2250 || native.is_empty() || peak[0] < 10.0 {
        return Err("incomplete rocking run".into());
    }
    Ok(Run {
        force,
        ticks,
        summary: json!({"public_ticks":public.len(),"native_calls":calls,"refined_ticks":refined.len(),"first_refined_tick_end_ns":refined.first(),"last_refined_tick_end_ns":refined.last(),"first_return_sample_ms":t,"peak_n":peak,"peak_time_ns":at,"normal_impulse_238_to_240ms_ns":impulse,"angular_impulse_238_to_240ms_nms":moment}),
    })
}

fn main() -> Result<()> {
    let [coarse, adaptive, fine, image, out]: [String; 5] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected COARSE ADAPTIVE FINE SVG JSON")?;
    let data = [
        read(Path::new(&coarse))?,
        read(Path::new(&adaptive))?,
        read(Path::new(&fine))?,
    ];
    let colors = [
        RGBColor(172, 79, 39),
        RGBColor(6, 120, 106),
        RGBColor(73, 83, 165),
    ];
    let ink = RGBColor(35, 48, 63);
    let muted = RGBColor(80, 99, 115);
    let svg = SVGBackend::new(&image, (845, 570)).into_drawing_area();
    svg.fill(&WHITE)?;
    svg.draw(&Text::new(
        "A gripper catches a returning edge",
        (14, 32),
        ("sans-serif", 25).into_font().color(&ink),
    ))?;
    svg.draw(&Text::new(
        "Left pad force during the impact · identical 200 µs command clocks",
        (15, 60),
        ("sans-serif", 16).into_font().color(&muted),
    ))?;
    for (i, (x, label)) in [(18, "Coarse"), (272, "Adaptive"), (564, "Continuous fine")]
        .into_iter()
        .enumerate()
    {
        svg.draw(&PathElement::new(
            [(x, 85), (x + 24, 85)],
            colors[i].stroke_width(3),
        ))?;
        svg.draw(&Text::new(
            format!(
                "{label}  {:.1} N",
                data[i].summary["peak_n"][0].as_f64().unwrap()
            ),
            (x + 31, 76),
            ("sans-serif", 16).into_font().color(&ink),
        ))?;
    }
    let graph = svg.clone().shrink((9, 106), (819, 271));
    let mut plot = ChartBuilder::on(&graph)
        .margin_top(5)
        .margin_right(8)
        .x_label_area_size(38)
        .y_label_area_size(63)
        .build_cartesian_2d(238.0_f64..239.55_f64, 0.0_f64..210.)?;
    plot.configure_mesh()
        .axis_desc_style(("sans-serif", 14))
        .label_style(("sans-serif", 13))
        .max_light_lines(0)
        .light_line_style(WHITE)
        .bold_line_style(RGBColor(226, 231, 235))
        .x_labels(7)
        .y_labels(5)
        .y_label_formatter(&|v| format!("{v:.0}"))
        .x_desc("Simulation time (ms)")
        .y_desc("Normal force (N)")
        .draw()?;
    for i in [2, 0, 1] {
        plot.draw_series(LineSeries::new(
            data[i].force.iter().copied(),
            colors[i].stroke_width(if i == 2 { 3 } else { 2 }),
        ))?;
    }
    svg.draw(&Text::new(
        format!(
            "Native solves per adaptive tick  ·  {} of {} ticks refined",
            data[1].summary["refined_ticks"], data[1].summary["public_ticks"]
        ),
        (17, 413),
        ("sans-serif", 18).into_font().color(&ink),
    ))?;
    let timing = svg.clone().shrink((9, 429), (819, 127));
    let mut clock = ChartBuilder::on(&timing)
        .margin_top(2)
        .margin_right(8)
        .x_label_area_size(38)
        .y_label_area_size(63)
        .build_cartesian_2d(237.0_f64..240.5_f64, 0.0_f64..215.)?;
    clock
        .configure_mesh()
        .axis_desc_style(("sans-serif", 14))
        .label_style(("sans-serif", 12))
        .x_labels(7)
        .y_labels(3)
        .x_label_formatter(&|v| format!("{v:.1}"))
        .max_light_lines(0)
        .bold_line_style(RGBColor(226, 231, 235))
        .x_desc("Simulation time (ms)")
        .y_desc("Solves / tick")
        .draw()?;
    clock.draw_series(
        data[1]
            .ticks
            .iter()
            .filter(|(end, _)| (236.8..=240.7).contains(end))
            .map(|&(end, n)| {
                Rectangle::new(
                    [(end - 0.19, 0.), (end - 0.01, n as f64)],
                    colors[1].mix(0.84).filled(),
                )
            }),
    )?;
    svg.present()?;
    fs::write(
        out,
        serde_json::to_vec_pretty(
            &json!({"coarse":data[0].summary,"adaptive":data[1].summary,"fine":data[2].summary}),
        )?,
    )?;
    Ok(())
}
