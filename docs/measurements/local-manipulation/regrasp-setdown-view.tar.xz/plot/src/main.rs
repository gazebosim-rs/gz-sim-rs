// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Draw the two manipulation sequences from the recorded native measurements.
use plotters::{coord::Shift, prelude::*};
use serde_json::{Value, json};
use std::{
    collections::BTreeMap,
    error::Error,
    fs::{self, File},
    io::{BufRead, BufReader},
    path::Path,
};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
type Area<'a> = DrawingArea<SVGBackend<'a>, Shift>;
const TEXT: RGBColor = RGBColor(28, 46, 59);
const SUB: RGBColor = RGBColor(67, 88, 101);
const AQUA: RGBColor = RGBColor(0, 109, 125);
const AMBER: RGBColor = RGBColor(184, 81, 26);
const GRID: RGBColor = RGBColor(223, 231, 232);
const PHASES: [[(&str, &str); 10]; 2] = [
    [
        ("baseline", "Intact grip"),
        ("left", "Left finger interruption"),
        ("right", "Right finger interruption"),
        ("dropout", "Sensor dropout"),
        ("brief", "Brief disturbance"),
        ("bounded", "Bounded finger force"),
        ("reacquire", "Renewed bilateral grip"),
        ("settling", "Settling confirmation"),
        ("repeat", "Repeated interruption"),
        ("prolonged", "Persistent loss"),
    ],
    [
        ("nominal", "Set down after loss"),
        ("brake", "Brake the lift"),
        ("high", "Higher receiver"),
        ("low", "Lower receiver"),
        ("heavy", "Heavier parcel"),
        ("mirror", "Mirrored mass offset"),
        ("dropout", "Interrupted load signal"),
        ("wrong", "Other surface"),
        ("missing", "Missing receiver"),
        ("edge", "Receiver edge"),
    ],
];
const SUITES: [&str; 2] = ["regrasp", "setdown"];

fn lines(path: &Path) -> Result<Vec<Value>> {
    BufReader::new(File::open(path)?)
        .lines()
        .map(|row| Ok(serde_json::from_str(&row?)?))
        .collect()
}

fn number(v: &Value, name: &str) -> Result<f64> {
    v[name]
        .as_f64()
        .filter(|v| v.is_finite())
        .ok_or_else(|| format!("missing finite {name}").into())
}

struct Run {
    samples: Vec<(u64, f64)>,
    frames: usize,
    checked: usize,
    error_m: f64,
    final_state: String,
    last_decision: Option<(f64, f64)>,
}
impl Run {
    fn read(dir: &Path, suite: usize, case: &str) -> Result<Self> {
        let ticks = lines(&dir.join("ticks.jsonl"))?;
        let mut poses = BTreeMap::new();
        let mut samples = Vec::new();
        let mut final_state = String::new();
        let mut last_decision = None;
        for t in ticks {
            let ns = t["time_ns"].as_u64().ok_or("missing integer tick")?;
            let pad = number(&t, "pad_z_m")?;
            let parcel = number(&t, "parcel_com_z_m")?;
            if poses.insert(ns, (pad, parcel)).is_some() {
                return Err("duplicated physics time".into());
            }
            let value_m = if suite == 0 {
                number(&t, "slip_m")?
            } else {
                parcel
            };
            let state = t["state"].as_str().ok_or("missing controller state")?;
            if state != final_state {
                final_state = state.to_owned();
                if ns > 210_000_000 {
                    last_decision = Some((ns as f64 / 1e6, 1000. * value_m));
                }
            }
            samples.push((ns, 1000. * value_m));
        }
        if samples.windows(2).any(|p| p[0].0 >= p[1].0) {
            return Err("physics clock moved backwards".into());
        }
        let mut checked = 0;
        let mut error_m: f64 = 0.;
        let mut frames = 0;
        let mut last_clock = None;
        for f in lines(&dir.join("epoch-0/frames.jsonl"))? {
            if f["kind"] != "frame" {
                continue;
            }
            frames += 1;
            if f["ordinal"] != frames {
                return Err("nonconsecutive archive ordinal".into());
            }
            let scene: Value = serde_json::from_str(f["scene"].as_str().ok_or("scene payload")?)?;
            let ns = scene["seconds"].as_u64().ok_or("seconds")? * 1_000_000_000
                + scene["nanoseconds"].as_u64().ok_or("nanoseconds")?;
            if last_clock.is_some_and(|old| old >= ns) {
                return Err("nonmonotonic archive clock".into());
            }
            last_clock = Some(ns);
            if ns == 0 {
                continue;
            }
            let (expected_pad, expected_parcel) = poses.get(&ns).ok_or("unmatched replay time")?;
            let visuals = scene["visuals"].as_array().ok_or("missing visuals")?;
            let link = |name: &str| -> Result<&Value> {
                visuals
                    .iter()
                    .find(|v| v["name"] == name)
                    .ok_or_else(|| format!("no rendered {name}").into())
            };
            let left = link("default::gripper::left::pad")?;
            let right = link("default::gripper::right::pad")?;
            let block = link("default::parcel::body::block")?;
            let z = |v: &Value| -> Result<f64> {
                v["translation"][2]
                    .as_f64()
                    .ok_or_else(|| "link height".into())
            };
            let q = block["rotation"].as_array().ok_or("link quaternion")?;
            let quat: Vec<f64> = q
                .iter()
                .map(|v| v.as_f64().ok_or("non-numeric quaternion"))
                .collect::<std::result::Result<_, _>>()?;
            let [x, y, zq, w]: [f64; 4] = quat.try_into().map_err(|_| "quaternion size")?;
            let dx = if suite == 1 && case == "mirror" {
                -0.0045
            } else {
                0.0045
            };
            let parcel = z(block)? + 2. * (x * zq - y * w) * dx;
            let pad = (z(left)? + z(right)?) * 0.5;
            error_m = error_m
                .max((parcel - expected_parcel).abs())
                .max((pad - expected_pad).abs());
            checked += 1;
        }
        if checked == 0 || error_m > 1e-10 {
            return Err(format!(
                "{}: {checked} compared; pose discrepancy {error_m} m",
                dir.display()
            )
            .into());
        }
        Ok(Self {
            samples,
            frames,
            checked,
            error_m,
            final_state,
            last_decision,
        })
    }
}

fn label(area: &Area, x: i32, y: i32, size: u32, color: RGBColor, message: &str) -> Result<()> {
    area.draw(&Text::new(
        message,
        (x, y),
        ("sans-serif", size).into_font().color(&color),
    ))?;
    Ok(())
}

fn main() -> Result<()> {
    let [root, svg, report]: [String; 3] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected RECORDING_ROOT OUTPUT.svg METRICS.json")?;
    let root = Path::new(&root);
    let mut results = BTreeMap::new();
    let mut text = String::new();
    {
        let canvas = SVGBackend::with_string(&mut text, (1450, 1660)).into_drawing_area();
        canvas.fill(&WHITE)?;
        label(
            &canvas,
            26,
            17,
            32,
            TEXT,
            "Recovering a parcel after finger contact is lost",
        )?;
        label(
            &canvas,
            26,
            66,
            18,
            SUB,
            "The gripper can close again during a lift, or bring the parcel to a receiving surface.",
        )?;
        for (col, x, title, caption) in [
            (
                0,
                25,
                "Regain contact",
                "Downward travel relative to the fingers (mm)",
            ),
            (
                1,
                748,
                "Set the parcel down",
                "Parcel center-of-mass height in the world (mm)",
            ),
        ] {
            label(&canvas, x, 105, 24, TEXT, title)?;

            let main_case = if col == 0 {
                "left-adaptive"
            } else {
                "nominal-adaptive"
            };
            let scene_dir = root.join(SUITES[col]).join(main_case);
            let summary: Value =
                serde_json::from_slice(&fs::read(scene_dir.join("summary.json"))?)?;
            let browser: Value =
                serde_json::from_slice(&fs::read(scene_dir.join("browser.json"))?)?;
            let capture = number(&browser["captured_ms"], "comparison")?;
            let details = if col == 0 {
                let transition = summary["state_transitions"]
                    .as_array()
                    .and_then(|a| a.last())
                    .ok_or("missing regrasp state")?;
                vec![
                    format!("Left jaw interruption at {capture:.0} ms"),
                    format!(
                        "Maximum parcel drop   {:.3} mm",
                        1000. * number(&summary, "max_slip_m")?
                    ),
                    format!(
                        "Grip confirmed   {:.1} ms",
                        number(transition, "time_ns")? / 1e6
                    ),
                ]
            } else {
                let ms = number(&summary, "dt_ns")? / 1e6;
                vec![
                    format!("Parcel on pedestal at {capture:.0} ms"),
                    format!(
                        "Opening authorized   {:.1} ms",
                        number(&summary, "opening_tick")? * ms
                    ),
                    format!(
                        "Gripper clear   {:.1} ms",
                        number(&summary, "clear_tick")? * ms
                    ),
                ]
            };
            for (idx, line) in details.iter().enumerate() {
                label(
                    &canvas,
                    x + 271,
                    183 + 44 * idx as i32,
                    18,
                    if idx == 0 { TEXT } else { SUB },
                    line,
                )?;
            }
            label(&canvas, x, 384, 19, TEXT, caption)?;
            for (idx, (case, title)) in PHASES[col].iter().enumerate() {
                let folder = root.join(SUITES[col]);
                let adaptive = Run::read(&folder.join(format!("{case}-adaptive")), col, case)?;
                let fine = Run::read(&folder.join(format!("{case}-fine")), col, case)?;
                if adaptive.samples.len() != fine.samples.len()
                    || adaptive
                        .samples
                        .iter()
                        .zip(&fine.samples)
                        .any(|(a, b)| a.0 != b.0)
                {
                    return Err(format!("{case}: clocks differ between fidelities").into());
                }
                let tx = x + (idx % 2) as i32 * 350;
                let ty = 466 + (idx / 2) as i32 * 187;
                label(
                    &canvas,
                    tx,
                    ty,
                    17,
                    TEXT,
                    &format!("{title} · {}", adaptive.final_state),
                )?;
                let begin = 210_000_000;
                let points = |r: &Run| {
                    r.samples
                        .iter()
                        .filter(|p| p.0 >= begin)
                        .map(|&(ns, y)| (ns as f64 / 1e6, y))
                        .collect::<Vec<_>>()
                };
                let a = points(&adaptive);
                let f = points(&fine);
                let end = a.last().ok_or("no post-event samples")?.0;
                let ymin = a
                    .iter()
                    .chain(&f)
                    .map(|p| p.1)
                    .fold(f64::INFINITY, f64::min);
                let ymax = a
                    .iter()
                    .chain(&f)
                    .map(|p| p.1)
                    .fold(f64::NEG_INFINITY, f64::max);
                let pad = (ymax - ymin).max(0.2) * 0.085;
                let pane = canvas
                    .clone()
                    .shrink((tx as u32, (ty + 25) as u32), (330, 142));
                let mut chart = ChartBuilder::on(&pane)
                    .margin_top(7)
                    .margin_right(14)
                    .x_label_area_size(28)
                    .y_label_area_size(51)
                    .build_cartesian_2d(begin as f64 / 1e6..end, ymin - pad..ymax + pad)?;
                chart
                    .configure_mesh()
                    .x_labels(4)
                    .y_labels(3)
                    .max_light_lines(0)
                    .label_style(("sans-serif", 13))
                    .y_label_formatter(&|y| {
                        if ymax - ymin < 0.4 {
                            format!("{y:.2}")
                        } else if ymax - ymin < 3. {
                            format!("{y:.1}")
                        } else {
                            format!("{y:.0}")
                        }
                    })
                    .bold_line_style(GRID)
                    .draw()?;
                chart.draw_series(LineSeries::new(a.iter().copied(), AQUA.stroke_width(2)))?;
                let stride = (f.len() / 14).max(1);
                chart.draw_series(
                    f.iter()
                        .skip(stride / 2)
                        .step_by(stride)
                        .map(|p| Circle::new(*p, 3, AMBER.filled())),
                )?;
                if let Some(event) = adaptive.last_decision {
                    chart.draw_series(std::iter::once(TriangleMarker::new(
                        event,
                        5,
                        RGBColor(81, 56, 117).filled(),
                    )))?;
                }
                results.insert(format!("{}/{case}",SUITES[col]), json!({
                    "phase":1 + idx + 10 * col, "description":title,
                    "archive_adaptive":format!("{}/{case}-adaptive/epoch-0", SUITES[col]),
                    "archive_fine":format!("{}/{case}-fine/epoch-0", SUITES[col]),
                    "adaptive_endpoint":adaptive.final_state, "fine_endpoint":fine.final_state,
                    "frames_adaptive":adaptive.frames,"frames_fine":fine.frames,
                    "native_frame_clocks_checked":adaptive.checked+fine.checked,
                    "max_archive_vs_native_height_difference_m":adaptive.error_m.max(fine.error_m),
                    "max_plotted_trajectory_difference_mm":a.iter().zip(&f).map(|(a,b)|(a.1-b.1).abs()).fold(0.,f64::max)
                }));
            }
        }
        canvas.draw(&PathElement::new(
            [(27, 429), (62, 429)],
            AQUA.stroke_width(3),
        ))?;
        label(&canvas, 73, 418, 16, SUB, "Adaptive physics")?;
        canvas.draw(&Circle::new((251, 429), 4, AMBER.filled()))?;
        label(&canvas, 265, 418, 16, SUB, "Continuously fine physics")?;
        label(
            &canvas,
            749,
            418,
            16,
            SUB,
            "Triangles mark the final state change. Time in ms; vertical scales vary by panel.",
        )?;

        label(
            &canvas,
            25,
            1410,
            22,
            TEXT,
            "What happens if one finger stays jammed?",
        )?;
        label(
            &canvas,
            25,
            1444,
            16,
            SUB,
            "Parcel vertical speed (m/s) around first receiver load. Time zero is the first tick with at least 10% of parcel weight on the receiver.",
        )?;
        let panel = canvas.clone().shrink((20, 1480), (660, 153));
        let mut chart = ChartBuilder::on(&panel)
            .margin(6)
            .x_label_area_size(39)
            .y_label_area_size(59)
            .build_cartesian_2d(-12_f64..12_f64, -0.8_f64..0.3_f64)?;
        chart
            .configure_mesh()
            .x_desc("Time from receiver contact (ms)")
            .x_labels(5)
            .y_labels(4)
            .max_light_lines(0)
            .bold_line_style(GRID)
            .label_style(("sans-serif", 13))
            .draw()?;
        let mut jammed_index = serde_json::Map::new();
        for (case, color, caption, top) in [
            ("nominal", AQUA, "Guided descent", 1495),
            ("jammed", AMBER, "Finger stays open", 1550),
        ] {
            for grid in ["adaptive", "fine"] {
                let dir = root.join("setdown").join(format!("{case}-{grid}"));
                let run = Run::read(&dir, 1, case)?;
                let summary: Value = serde_json::from_slice(&fs::read(dir.join("summary.json"))?)?;
                let arrival = number(&summary, "arrival_tick")? * number(&summary, "dt_ns")?;
                let series: Vec<_> = run
                    .samples
                    .windows(2)
                    .map(|w| {
                        let t = (w[1].0 as f64 - arrival) / 1e6;
                        let speed = (w[1].1 - w[0].1) * 1e6 / (w[1].0 - w[0].0) as f64;
                        (t, speed)
                    })
                    .filter(|p| p.0.abs() <= 12.)
                    .collect();
                let approach = series
                    .iter()
                    .rev()
                    .find(|p| p.0 < 0.)
                    .ok_or("no incoming receiver interval")?
                    .1;
                if grid == "adaptive" {
                    chart.draw_series(LineSeries::new(
                        series.iter().copied(),
                        color.stroke_width(2),
                    ))?;
                    label(&canvas, 748, top, 18, color, caption)?;
                    label(
                        &canvas,
                        748,
                        top + 25,
                        16,
                        TEXT,
                        &format!(
                            "{:.3} m/s downward just before the receiver took load.",
                            -approach
                        ),
                    )?;
                } else {
                    chart.draw_series(
                        series
                            .iter()
                            .step_by(9)
                            .map(|p| Circle::new(*p, 3, color.filled())),
                    )?;
                }
                if case == "jammed" {
                    jammed_index.insert(grid.into(),json!({"archive":format!("setdown/{case}-{grid}/epoch-0"),"frames":run.frames,
                      "native_frame_clocks_checked":run.checked,"max_archive_vs_native_height_difference_m":run.error_m,
                      "incoming_m_s":approach,"receiver_contact_ms":arrival/1e6,"endpoint":run.final_state}));
                }
            }
        }
        results.insert(
            "setdown/jammed".to_string(),
            json!({"supplement_to_phase":11,"recordings":jammed_index}),
        );
        canvas.present()?;
    }
    let mut embeds = String::new();
    for (tag, x, case) in [("regrasp", 25, "left"), ("setdown", 748, "nominal")] {
        let path = format!("{tag}/{case}-adaptive/comparison.jpg");
        if !root.join(&path).is_file() {
            return Err(format!("missing viewer capture {path}").into());
        }
        embeds.push_str(&format!(r##"<defs><clipPath id="{tag}"><rect x="{x}" y="143" width="243" height="212"/></clipPath></defs><g clip-path="url(#{tag})"><image xmlns:xlink="http://www.w3.org/1999/xlink" transform="translate({x},143) scale(0.38) translate(-440,-219)" width="1440" height="900" xlink:href="{path}"/></g>"##));
    }
    text.insert_str(text.rfind("</svg>").ok_or("SVG terminator")?, &embeds);
    fs::write(svg, text)?;
    fs::write(report, serde_json::to_vec_pretty(&results)?)?;
    Ok(())
}
