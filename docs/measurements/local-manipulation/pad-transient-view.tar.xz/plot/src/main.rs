// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Recover the geometric overlap on each sphere/box face from native replay.
use glam::{DQuat, DVec3};
use plotters::prelude::*;
use serde_json::{Value, json};
use std::{
    error::Error,
    fs::File,
    io::{BufRead, BufReader},
    path::Path,
};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
struct Reading {
    seconds: f64,
    compression_um: [f64; 2],
    height_m: f64,
}
fn read(dir: &Path) -> Result<Vec<Reading>> {
    let mut samples = Vec::new();
    for line in BufReader::new(File::open(dir.join("frames.jsonl"))?).lines() {
        let frame: Value = serde_json::from_str(&line?)?;
        if frame["kind"] != "frame" {
            continue;
        }
        let scene: Value = serde_json::from_str(frame["scene"].as_str().ok_or("missing scene")?)?;
        let nanos = scene["seconds"].as_u64().ok_or("clock")? * 1_000_000_000
            + scene["nanoseconds"].as_u64().ok_or("clock fraction")?;
        if nanos != samples.len() as u64 * 1_000_000 {
            return Err("expected 1 ms captures".into());
        }
        let visuals = scene["visuals"].as_array().ok_or("visuals")?;
        let part = |name: &str| {
            visuals
                .iter()
                .find(|v| v["name"] == name)
                .ok_or("missing visual")
        };
        let center = |v: &Value| -> Result<DVec3> {
            Ok(DVec3::from_array(serde_json::from_value(
                v["translation"].clone(),
            )?))
        };
        let sphere = part("default::parcel::body::sphere")?;
        let p = center(sphere)?;
        let radius = sphere["shape"]["radius"]
            .as_f64()
            .ok_or("sphere geometry")?;
        let mut compression = [0.; 2];
        for (side, pad_name) in [
            "default::gripper::left::pad",
            "default::gripper::right::pad",
        ]
        .iter()
        .enumerate()
        {
            let pad = part(pad_name)?;
            let q = DQuat::from_array(serde_json::from_value(pad["rotation"].clone())?);
            let half =
                0.5 * DVec3::from_array(serde_json::from_value(pad["shape"]["size"].clone())?);
            let local = q.conjugate() * (p - center(pad)?);
            let outside = (local.abs() - half).max(DVec3::ZERO);
            compression[side] = (radius - outside.length()).max(0.0) * 1e6;
        }
        samples.push(Reading {
            seconds: nanos as f64 * 1e-9,
            compression_um: compression,
            height_m: p.z,
        });
    }
    if samples.len() != 461 {
        return Err("expected 460 ms of native measurements".into());
    }
    Ok(samples)
}
impl Reading {
    fn mean_um(&self) -> f64 {
        (self.compression_um[0] + self.compression_um[1]) / 2.
    }
}

fn main() -> Result<()> {
    let [root, plot, data]: [String; 3] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected RECORDINGS SVG JSON")?;
    let root = Path::new(&root);
    let cases = ["before-25", "before-200", "after-25", "after-200"];
    let mut runs = Vec::new();
    let mut doc = json!({"columns":["time_ms","left_overlap_um","right_overlap_um","sphere_height_mm"],"runs":{}});
    for name in cases {
        let run = read(&root.join(name).join("epoch-0"))?;
        let rows: Vec<_> = run
            .iter()
            .map(|p| {
                json!([
                    (p.seconds * 1000.).round() as u64,
                    p.compression_um[0],
                    p.compression_um[1],
                    p.height_m * 1000.
                ])
            })
            .collect();
        doc["runs"][name] = json!(rows);
        runs.push(run);
    }
    std::fs::write(data, serde_json::to_vec(&doc)?)?;

    let canvas = SVGBackend::new(&plot, (810, 438)).into_drawing_area();
    canvas.fill(&WHITE)?;
    let ink = RGBColor(36, 48, 61);
    let gray = RGBColor(82, 96, 110);
    let colors = [
        RGBColor(154, 79, 36),
        RGBColor(209, 135, 77),
        RGBColor(20, 99, 117),
        RGBColor(15, 139, 111),
    ];
    canvas.draw(&Text::new(
        "Gripper pads under a changing load",
        (20, 12),
        ("sans-serif", 27).into_font().color(&ink),
    ))?;
    canvas.draw(&Text::new(
        "Measured overlap per pad on a 200 g sphere",
        (21, 48),
        ("sans-serif", 17).into_font().color(&gray),
    ))?;
    let area = canvas.margin(105, 12, 18, 18);
    let mut chart = ChartBuilder::on(&area)
        .margin(3)
        .set_label_area_size(LabelAreaPosition::Left, 62)
        .set_label_area_size(LabelAreaPosition::Bottom, 47)
        .build_cartesian_2d(0f64..376f64, 0f64..118f64)?;
    chart
        .configure_mesh()
        .x_labels(8)
        .y_labels(6)
        .max_light_lines(0)
        .x_desc("Time (ms)")
        .y_desc("Compression (µm)")
        .axis_desc_style(("sans-serif", 16).into_font().color(&ink))
        .label_style(("sans-serif", 14).into_font().color(&gray))
        .bold_line_style(RGBColor(227, 230, 234))
        .draw()?;
    for (time, label, x) in [
        (0., "3 N squeeze", 8.),
        (300., "1.5 N", 301.),
        (360., "Open", 346.),
    ] {
        chart.draw_series([PathElement::new(
            vec![(time, 0.), (time, 108.)],
            RGBColor(187, 195, 202),
        )])?;
        chart.draw_series([Text::new(
            label,
            (x, 114.),
            ("sans-serif", 14).into_font().color(&gray),
        )])?;
    }
    for (i, run) in runs.iter().enumerate() {
        let line = run
            .iter()
            .take(377)
            .map(|p| (p.seconds * 1000., p.mean_um()));
        if i == 3 {
            chart.draw_series(
                line.step_by(10)
                    .map(|p| Circle::new(p, 3, colors[i].stroke_width(2))),
            )?;
        } else {
            chart.draw_series(LineSeries::new(line, colors[i].stroke_width(3)))?;
        }
    }
    for (i, (x, label)) in [
        (23, "Prior 25 µs"),
        (202, "Prior 200 µs"),
        (393, "Revised 25 µs"),
        (599, "Revised 200 µs"),
    ]
    .into_iter()
    .enumerate()
    {
        if i == 3 {
            canvas.draw(&Circle::new((x + 6, 84), 4, colors[i].stroke_width(2)))?;
        } else {
            canvas.draw(&PathElement::new(
                vec![(x, 84), (x + 16, 84)],
                colors[i].stroke_width(3),
            ))?;
        }
        canvas.draw(&Text::new(
            label,
            (x + 23, 76),
            ("sans-serif", 15).into_font().color(&ink),
        ))?;
    }
    canvas.present()?;
    Ok(())
}
