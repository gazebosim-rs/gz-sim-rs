// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Read native link states directly at the physical times used in the viewer.
use gz_physics::PhysicsBackend;
use gz_sim_core::{EntityId, Simulation};
use gz_sim_scene::{BodyHandle, Name, PhysicsEngine, load_world_with_sdf_step, set_joint_force};
use serde_json::{Value, json};
use std::{error::Error, io::Write};

const LINKS: [(&str, &str); 4] = [
    ("wrist", "default::gripper::wrist"),
    ("left", "default::gripper::left"),
    ("right", "default::gripper::right"),
    ("parcel", "default::parcel::body"),
];

fn record(sim: &Simulation, time_ns: u64) -> Result<Value, Box<dyn Error>> {
    let engine = sim.world().resource::<PhysicsBackend>();
    let mut poses = serde_json::Map::new();
    for (short, scoped) in LINKS {
        #[allow(deprecated)]
        let handle = sim
            .world()
            .iter_entities()
            .find(|e| e.get::<Name>().is_some_and(|n| n.0 == scoped))
            .and_then(|e| e.get::<BodyHandle>())
            .ok_or("missing link")?;
        let state = engine.state(handle.id()).ok_or("missing body state")?;
        poses.insert(
            short.into(),
            json!({"translation":state.position,"rotation":state.orientation}),
        );
    }
    Ok(json!({"time_ns": time_ns, "poses": poses}))
}

fn main() -> Result<(), Box<dyn Error>> {
    let world = std::env::args().nth(1).ok_or("expected WORLD")?;
    let xml = std::fs::read_to_string(&world)?;
    let mut sim = load_world_with_sdf_step(
        &xml,
        &world,
        "default",
        &sdformat::NoResources,
        PhysicsEngine::MultiFidelity,
    )?;
    let step_ns = u64::try_from(sim.step_duration().as_nanos())?;
    if !matches!(step_ns, 25_000 | 200_000) {
        return Err("expected the fine or coarse qualification clock".into());
    }
    let stride = 1_000_000 / step_ns;
    let mut motors = vec![];
    for name in [
        "default::gripper::left_slide",
        "default::gripper::right_slide",
    ] {
        #[allow(deprecated)]
        let entity = sim
            .world()
            .iter_entities()
            .find(|e| e.get::<Name>().is_some_and(|n| n.0 == name))
            .ok_or("missing slider")?;
        motors.push(entity.get::<EntityId>().ok_or("missing entity id")?.get());
    }
    let mut poses = vec![record(&sim, 0)?];
    let mut tick = 0;
    for (force, duration_ms) in [(3.0, 300), (1.5, 60), (-3.0, 100)] {
        for &id in &motors {
            set_joint_force(&mut sim, id, force)?;
        }
        for _ in 0..duration_ms {
            sim.step_exact(stride)?;
            tick += stride;
            poses.push(record(&sim, tick * step_ns)?);
        }
    }
    std::io::stdout()
        .lock()
        .write_all(&serde_json::to_vec(&poses)?)?;
    Ok(())
}
