// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Plot signed native friction data and parcel slip relative to the moving pads.
use plotters::prelude::*;
use serde_json::{Value, json};
use std::{
    collections::BTreeMap,
    error::Error,
    fs::{self, File},
    io::{BufRead, BufReader},
    path::Path,
};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
struct Run {
    drop_mm: Vec<(f64, f64)>,
    upward_n: Vec<(f64, f64)>,
    summary: Value,
}
fn number(r: &Value, key: &str) -> Result<f64> {
    r[key]
        .as_f64()
        .ok_or_else(|| format!("missing {key}").into())
}
fn read(root: &Path, label: &str) -> Result<Run> {
    let rows: Vec<Value> = BufReader::new(File::open(root.join(label).join("public.jsonl"))?)
        .lines()
        .map(|l| Ok(serde_json::from_str(&l?)?))
        .collect::<Result<_>>()?;
    let at = |ns| {
        rows.iter()
            .find(|r| r["time_ns"] == ns)
            .ok_or("missing phase boundary")
    };
    let z_gap =
        |r: &Value| -> Result<f64> { Ok(number(r, "pad_z_m")? - number(r, "parcel_com_z_m")?) };
    let lift = at(150_000_000)?;
    let release = at(210_000_000)?;
    let end = at(290_000_000)?;
    let before = z_gap(release)?;
    let mut counts = BTreeMap::new();
    let mut drop_mm = Vec::new();
    let mut upward_n = Vec::new();
    let mut max_pitch: f64 = 0.;
    for (i, row) in rows.iter().enumerate() {
        let ns = row["time_ns"].as_u64().ok_or("missing clock")?;
        assert_eq!(ns, 200_000 * (i + 1) as u64);
        *counts
            .entry(row["native_calls"].as_u64().ok_or("native calls")?)
            .or_insert(0_u64) += 1;
        if ns >= 145_000_000 {
            let t = ns as f64 * 1e-6;
            drop_mm.push((t, 1000. * (z_gap(row)? - before)));
            let impulse = &row["vertical_friction_ns"];
            upward_n.push((
                t,
                (impulse[0].as_f64().ok_or("left friction")?
                    + impulse[1].as_f64().ok_or("right friction")?)
                    / 0.0002,
            ));
        }
        if ns >= 210_000_000 {
            max_pitch = max_pitch.max(number(row, "pitch_deg")?.abs());
        }
    }
    let summary = json!({
        "public_steps": rows.len(),
        "public_ticks_by_native_calls": counts,
        "pad_rise_after_lift_start_mm":1000.*(number(end,"pad_z_m")?-number(lift,"pad_z_m")?),
        "parcel_com_rise_after_lift_start_mm":1000.*(number(end,"parcel_com_z_m")?-number(lift,"parcel_com_z_m")?),
        "com_drop_relative_to_pads_after_210ms_mm":1000.*(z_gap(end)?-before),
        "max_absolute_pitch_after_210ms_deg":max_pitch
    });
    Ok(Run {
        drop_mm,
        upward_n,
        summary,
    })
}
fn main() -> Result<()> {
    let [src, svg, out]: [String; 3] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected DATA_DIRECTORY SVG JSON")?;
    let root = Path::new(&src);
    let labels = [
        "hold",
        "slip",
        "fine-hold",
        "fine-slip",
        "rock",
        "fine-rock",
    ];
    let runs = labels
        .iter()
        .map(|s| read(root, s))
        .collect::<Result<Vec<_>>>()?;
    let summaries = labels
        .into_iter()
        .zip(&runs)
        .map(|(k, r)| (k, r.summary.clone()))
        .collect::<BTreeMap<_, _>>();
    let colors = [RGBColor(0, 111, 100), RGBColor(167, 76, 34)];
    let ink = RGBColor(34, 48, 64);
    let muted = RGBColor(71, 91, 103);
    let grid = RGBColor(219, 226, 231);
    let mut text = String::new();
    {
        let d = SVGBackend::with_string(&mut text, (1200, 654)).into_drawing_area();
        d.fill(&WHITE)?;
        let label = |x, y, t: &str, sz| {
            d.draw(&Text::new(
                t,
                (x, y),
                ("sans-serif", sz).into_font().color(&ink),
            ))
        };
        label(26, 25, "Can the gripper carry an off-center parcel?", 29)?;
        d.draw(&Text::new(
            "200 g parcel  ·  center of mass offset 4.5 mm  ·  upward lift begins at 150 ms",
            (26, 64),
            ("sans-serif", 16).into_font().color(&muted),
        ))?;
        for (i, (x, name)) in [
            (26, "4.2 N grip per finger"),
            (249, "Grip reduced to 2.3 N"),
        ]
        .into_iter()
        .enumerate()
        {
            d.draw(&PathElement::new(
                [(x, 104), (x + 25, 104)],
                colors[i].stroke_width(3),
            ))?;
            label(x + 33, 95, name, 17)?;
        }
        d.draw(&Circle::new((518, 104), 4, ink.stroke_width(2)))?;
        label(530, 95, "Continuous fine samples", 16)?;
        for panel in 0..2 {
            let title_y = if panel == 0 { 144 } else { 387 };
            label(
                26,
                title_y,
                if panel == 0 {
                    "Parcel drop relative to the moving fingers"
                } else {
                    "Total upward friction force on the parcel"
                },
                19,
            )?;
            let upper = d.clone().shrink((15, title_y as u32 + 30), (722, 194));
            let yr = if panel == 0 { -0.4..11.0 } else { 1.75..2.94 };
            let mut chart = ChartBuilder::on(&upper)
                .margin_top(4)
                .margin_right(12)
                .x_label_area_size(42)
                .y_label_area_size(63)
                .build_cartesian_2d(145.0_f64..290.0_f64, yr.clone())?;
            chart
                .configure_mesh()
                .max_light_lines(0)
                .bold_line_style(grid)
                .axis_desc_style(("sans-serif", 15))
                .label_style(("sans-serif", 13))
                .x_labels(8)
                .y_labels(6)
                .x_desc("Simulation time (ms)")
                .y_desc(if panel == 0 { "Drop (mm)" } else { "Force (N)" })
                .draw()?;
            chart.draw_series(std::iter::once(PathElement::new(
                [(210., yr.start), (210., yr.end)],
                RGBColor(129, 143, 151).stroke_width(1),
            )))?;
            for i in 0..2 {
                let series = |run: &Run| {
                    if panel == 0 {
                        run.drop_mm.clone()
                    } else {
                        run.upward_n.clone()
                    }
                };
                chart.draw_series(LineSeries::new(series(&runs[i]), colors[i].stroke_width(3)))?;
                for (t, y) in series(&runs[i + 2])
                    .into_iter()
                    .skip(if i == 0 { 10 } else { 24 })
                    .step_by(54)
                {
                    chart.draw_series(std::iter::once(Circle::new((t, y), 3, WHITE.filled())))?;
                    chart.draw_series(std::iter::once(Circle::new(
                        (t, y),
                        3,
                        colors[i].stroke_width(1),
                    )))?;
                }
            }
        }
        label(
            26,
            626,
            "At 210 ms the weaker grip starts unloading. Both lifts keep the same motor effort.",
            15,
        )?;
        label(777, 25, "gz-web-rs at 290 ms", 25)?;
        label(777, 85, "4.2 N  ·  Parcel held", 18)?;
        label(777, 342, "2.3 N  ·  Parcel slipped 10.09 mm", 18)?;
        label(777, 626, "Same camera position and scale", 15)?;
        d.present()?;
    }
    let mut captures = String::new();
    for (name, y) in [("hold", 118), ("slip", 374)] {
        if !root.join(name).join("lifted.jpg").is_file() {
            return Err(format!("missing {name} screenshot").into());
        }
        captures.push_str(&format!(r##"<defs><clipPath id="{name}"><rect x="777" y="{y}" width="392" height="203"/></clipPath></defs><g clip-path="url(#{name})"><image xmlns:xlink="http://www.w3.org/1999/xlink" transform="translate(777,{y}) scale(0.54) translate(-385,-258)" width="1440" height="900" xlink:href="{name}/lifted.jpg"/></g>"##));
    }
    text.insert_str(text.rfind("</svg>").ok_or("invalid SVG")?, &captures);
    fs::write(svg, text)?;
    fs::write(out, serde_json::to_vec_pretty(&summaries)?)?;
    Ok(())
}
