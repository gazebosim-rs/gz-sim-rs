// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Measure parcel and pad motion and the signed friction impulses in the local lifting gripper.
use bevy_ecs::prelude::{Res, ResMut};
use bevy_tasks::{ComputeTaskPool, TaskPoolBuilder};
use glam::{DQuat, DVec3};
use gz_physics::{BodyId, PhysicsBackend};
use gz_physics_multifidelity::{ContactSubstep, MultiFidelityBackend, RigidContactPatch};
use gz_sim_core::{EntityId, Phase, Simulation, UpdateInfo};
use gz_sim_scene::{
    BodyHandle, Name, PhysicsEngine, load_world_with_sdf_step, queue_link_world_wrench,
    set_joint_force,
};
use serde_json::{Value, json};
use std::collections::BTreeMap;
use std::error::Error;
use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::Duration;

type Result<T> = std::result::Result<T, Box<dyn Error>>;

#[derive(Clone)]
struct Links {
    ids: BTreeMap<String, u64>,
    bodies: BTreeMap<String, BodyId>,
    pads: [BodyId; 2],
    parcel: BodyId,
}

impl Links {
    fn read(sim: &Simulation) -> Result<Self> {
        let mut ids = BTreeMap::new();
        let mut bodies = BTreeMap::new();
        #[allow(deprecated)]
        for entity in sim.world().iter_entities() {
            if let (Some(id), Some(name)) = (entity.get::<EntityId>(), entity.get::<Name>()) {
                ids.insert(name.0.clone(), id.get());
                if let Some(body) = entity.get::<BodyHandle>() {
                    bodies.insert(name.0.clone(), body.id());
                }
            }
        }
        let pads = [
            bodies["default::gripper::left"],
            bodies["default::gripper::right"],
        ];
        let parcel = bodies["default::parcel::body"];
        Ok(Self {
            ids,
            bodies,
            pads,
            parcel,
        })
    }

    fn poses(&self, engine: &PhysicsBackend, time_ns: u64) -> Result<Value> {
        let mut poses = serde_json::Map::new();
        for (name, id) in &self.bodies {
            let s = engine.state(*id).ok_or("missing native state")?;
            poses.insert(
                name.clone(),
                json!({"translation":s.position, "rotation":s.orientation}),
            );
        }
        Ok(json!({"time_ns":time_ns, "poses":poses}))
    }
}

#[derive(Clone, Copy)]
struct Sample {
    end_ns: u64,
    ns: u64,
    force: [f64; 2],
    moment: [f64; 2],
    vertical_friction_ns: [f64; 2],
}

impl Sample {
    fn read(
        links: &Links,
        time: Duration,
        step: Duration,
        patches: Vec<RigidContactPatch>,
    ) -> Self {
        let mut sample = Self {
            end_ns: time.as_nanos() as u64,
            ns: step.as_nanos() as u64,
            force: [0.; 2],
            moment: [0.; 2],
            vertical_friction_ns: [0.; 2],
        };
        for patch in patches {
            let on_a = patch.a == links.parcel;
            let other = if on_a {
                patch.b
            } else if patch.b == links.parcel {
                patch.a
            } else {
                continue;
            };
            let Some(side) = links.pads.iter().position(|id| *id == other) else {
                continue;
            };
            let sign = if on_a { 1.0 } else { -1.0 };
            for p in patch.points {
                let n = p.normal_impulse;
                let lever = if on_a { p.lever_a } else { p.lever_b };
                let impulse = sign
                    * (n * DVec3::from(patch.normal_on_a)
                        + DVec3::from(p.tangent_impulse_on_a.unwrap()));
                sample.vertical_friction_ns[side] += sign * p.tangent_impulse_on_a.unwrap()[2];
                sample.force[side] += n / step.as_secs_f64();
                sample.moment[side] += DVec3::from(lever).cross(impulse).y / step.as_secs_f64();
            }
        }
        sample
    }
}

fn main() -> Result<()> {
    let [mode, world, journal, dir, threads]: [String; 5] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected MODE WORLD JOURNAL OUT THREADS")?;
    ComputeTaskPool::get_or_init(|| {
        TaskPoolBuilder::new()
            .num_threads(threads.parse().unwrap())
            .build()
    });
    let dir = PathBuf::from(dir);
    fs::create_dir_all(&dir)?;
    let xml = fs::read_to_string(&world)?;
    let sdf = sdformat::load_str(&xml, &world, &sdformat::NoResources)?;
    let parcel_model = sdf.worlds[0]
        .models
        .iter()
        .find(|model| model.name == "parcel")
        .ok_or("missing parcel")?;
    let parcel_link = parcel_model
        .links
        .iter()
        .find(|link| link.name == "body")
        .ok_or("missing parcel body")?;
    let com_offset = DVec3::from(
        sdf.resolve_pose(
            &parcel_link.inertial.pose,
            &parcel_model.scoped_name,
            &parcel_link.scoped_name,
            &parcel_link.scoped_name,
        )?
        .translation,
    );
    let mut sim = load_world_with_sdf_step(
        &xml,
        &world,
        "default",
        &sdformat::NoResources,
        PhysicsEngine::MultiFidelity,
    )?;
    let commands: Value = serde_json::from_slice(&fs::read(journal)?)?;
    let links = Links::read(&sim)?;
    let queue = Arc::new(Mutex::new(Vec::new()));
    let probes = links.clone();
    let buffer = queue.clone();
    let record_native = move |tick: UpdateInfo, s: ContactSubstep<'_>| {
        buffer.lock().unwrap().push(Sample::read(
            &probes,
            tick.start_time + s.elapsed,
            s.duration,
            s.contact_patches(),
        ));
    };
    match mode.as_str() {
        "fine" => {
            assert_eq!(
                sim.remove_systems_in_set(Phase::PhysicsStep, Phase::PhysicsStep)?,
                1
            );
            sim.add_systems(
                Phase::PhysicsStep,
                move |t: Res<UpdateInfo>, mut backend: ResMut<PhysicsBackend>| {
                    assert_eq!(t.dt, Duration::from_micros(200));
                    backend
                        .downcast_mut::<MultiFidelityBackend>()
                        .unwrap()
                        .observe_contact_interval(t.dt, 200, 4, |s| record_native(*t, s))
                        .unwrap();
                },
            );
        }
        "adaptive" => gz_sim_scene::primary_contact::set_refined_observer(&mut sim, record_native)?,
        "coarse" => {}
        _ => return Err("expected fine, adaptive, or coarse".into()),
    }
    let dt = sim.step_duration();
    assert_eq!(dt, Duration::from_micros(200));
    let visual = gz_sim_cli::ArchiveVisuals::new(&sim)?;
    let mut frames = vec![visual.frame(&sim, &sdf, "default", 1)?];
    let mut poses = vec![links.poses(sim.world().resource(), 0)?];
    let mut ticks = BufWriter::new(File::create(dir.join("public.jsonl"))?);
    for cmd in commands["commands"].as_array().ok_or("commands")? {
        match cmd["op"].as_str().ok_or("op")? {
            "step" => {
                for _ in 0..cmd["count"].as_u64().ok_or("count")? {
                    sim.step_exact(1)?;
                    let info = sim.committed_update_info()?;
                    let engine = sim.world().resource::<PhysicsBackend>();
                    let mut q = queue.lock().unwrap();
                    if q.is_empty() {
                        q.push(Sample::read(
                            &links,
                            info.sim_time,
                            dt,
                            engine
                                .downcast_ref::<MultiFidelityBackend>()
                                .unwrap()
                                .rigid_contact_patches(),
                        ));
                    }
                    let mut force = [0.0; 2];
                    let mut moment = [0.0; 2];
                    let mut vertical_friction_ns = [0.; 2];
                    let mut start = info.start_time.as_nanos() as u64;
                    for s in q.iter() {
                        assert_eq!(start + s.ns, s.end_ns);
                        start = s.end_ns;
                        for side in 0..2 {
                            force[side] += s.force[side] * s.ns as f64 * 1e-9;
                            moment[side] += s.moment[side] * s.ns as f64 * 1e-9;
                            vertical_friction_ns[side] += s.vertical_friction_ns[side];
                        }
                    }
                    assert_eq!(start, info.sim_time.as_nanos() as u64);
                    let state = engine.state(links.parcel).unwrap();
                    let axis = DQuat::from_array(state.orientation) * DVec3::X;
                    let com_z =
                        state.position[2] + (DQuat::from_array(state.orientation) * com_offset).z;
                    let pad_z = 0.5
                        * links
                            .pads
                            .iter()
                            .map(|&id| engine.state(id).unwrap().position[2])
                            .sum::<f64>();
                    writeln!(
                        ticks,
                        "{}",
                        json!({"iteration":info.iteration,"time_ns":start,"native_calls":q.len(),"parcel_com_z_m":com_z,"pad_z_m":pad_z,"vertical_friction_ns":vertical_friction_ns,"normal_impulse_ns":force,"angular_impulse_nms":moment,"pitch_deg":(-axis.z).atan2(axis.x).to_degrees(),"spin_y_rad_s":state.angular_velocity[1]})
                    )?;
                    q.clear();
                    if info.iteration.is_multiple_of(5) {
                        poses.push(links.poses(engine, start)?);
                        frames.push(visual.frame(
                            &sim,
                            &sdf,
                            "default",
                            frames.len() as u64 + 1,
                        )?);
                    }
                }
            }
            "set_joint_force" => set_joint_force(
                &mut sim,
                links.ids[cmd["joint"].as_str().ok_or("joint")?],
                cmd["force"].as_f64().ok_or("force")?,
            )?,
            "wrench" => queue_link_world_wrench(
                &mut sim,
                links.ids[cmd["link"].as_str().ok_or("link")?],
                serde_json::from_value(cmd["force"].clone())?,
                serde_json::from_value(cmd["torque"].clone())?,
            )?,
            op => return Err(format!("unexpected command {op}").into()),
        }
    }
    ticks.flush()?;
    fs::write(dir.join("poses.json"), serde_json::to_vec(&poses)?)?;
    gz_sim_cli::export_archive_at(
        &dir.join("epoch-0"),
        visual.files(),
        sim.epoch(),
        Duration::ZERO,
        frames,
    )?;
    Ok(())
}
