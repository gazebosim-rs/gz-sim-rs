// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Compare a gripped parcel's pre-impact rotation and the pad force at touchdown.
use plotters::prelude::*;
use serde_json::{Value, json};
use std::{
    collections::BTreeMap,
    error::Error,
    fs::{self, File},
    io::{BufRead, BufReader},
    path::Path,
};

type Result<T> = std::result::Result<T, Box<dyn Error>>;

fn rows(path: &Path) -> Result<Vec<Value>> {
    BufReader::new(File::open(path)?)
        .lines()
        .map(|line| Ok(serde_json::from_str(&line?)?))
        .collect()
}

struct Run {
    force: Vec<(f64, f64)>,
    pitch: Vec<f64>,
    peaks: [f64; 2],
    peak_times: [u64; 2],
    impulses: [f64; 2],
    counts: BTreeMap<u64, usize>,
}

fn read(root: &Path, label: &str) -> Result<Run> {
    let dir = root.join(label);
    let mut run = Run {
        force: vec![],
        pitch: vec![],
        peaks: [0.; 2],
        peak_times: [0; 2],
        impulses: [0.; 2],
        counts: BTreeMap::new(),
    };
    for p in rows(&dir.join("public.jsonl"))? {
        let end = p["time_ns"].as_u64().ok_or("public time")?;
        let calls = p["native_calls"].as_u64().ok_or("native steps")?;
        let tilt = p["pitch_deg"].as_f64().ok_or("parcel pitch")?;
        assert_eq!(end, (run.pitch.len() + 1) as u64 * 200_000);
        *run.counts.entry(calls).or_default() += 1;
        run.pitch.push(tilt);
        if (238_000_000 < end) && (end <= 240_000_000) {
            for i in 0..2 {
                run.impulses[i] += p["normal_impulse_ns"][i].as_f64().ok_or("impulse")?;
                let peak = p["peak_n"][i].as_f64().ok_or("peak force")?;
                if peak > run.peaks[i] {
                    run.peaks[i] = peak;
                    run.peak_times[i] = p["peak_time_ns"][i].as_u64().ok_or("peak time")?;
                }
            }
        }
    }
    if run.pitch.len() != 2250 || run.peaks.iter().any(|p| *p < 100.) {
        return Err("incomplete load history".into());
    }
    for p in rows(&dir.join("native.jsonl"))? {
        let end_ns = p["time_ns"].as_u64().ok_or("native time")?;
        if (238_350_000..=239_350_000).contains(&end_ns) {
            let width = p["duration_ns"].as_u64().ok_or("native duration")?;
            let load = p["force_n"][0].as_f64().ok_or("native force")?;
            run.force.extend([
                ((end_ns - width) as f64 * 1e-6, load),
                (end_ns as f64 * 1e-6, load),
            ]);
        }
    }
    if run.force.is_empty() {
        return Err("missing native impact".into());
    }
    Ok(run)
}

fn main() -> Result<()> {
    let [src, svg_path, summary_path]: [String; 3] = std::env::args()
        .skip(1)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| "expected DATA_DIRECTORY SVG JSON")?;
    let root = Path::new(&src);
    let runs = [
        read(root, "edge")?,
        read(root, "approach")?,
        read(root, "fine")?,
    ];
    let labels = ["Edge-only", "Approach + edge", "Continuous fine"];
    let keys = ["edge", "approach", "fine"];
    let colors = [
        RGBColor(175, 76, 34),
        RGBColor(2, 109, 103),
        RGBColor(73, 87, 159),
    ];
    let ink = RGBColor(32, 47, 63);
    let subtle = RGBColor(78, 95, 108);
    let grid = RGBColor(220, 227, 230);
    let mut text = String::new();
    let mut summary = serde_json::Map::new();
    {
        let drawing = SVGBackend::with_string(&mut text, (1170, 628)).into_drawing_area();
        drawing.fill(&WHITE)?;
        drawing.draw(&Text::new(
            "Timing the gripper’s returning edge",
            (24, 25),
            ("sans-serif", 29).into_font().color(&ink),
        ))?;
        drawing.draw(&Text::new(
            "Same 200 µs command clock and single torque pulse in all three runs",
            (25, 60),
            ("sans-serif", 17).into_font().color(&subtle),
        ))?;
        for (i, x) in [25, 239, 530].into_iter().enumerate() {
            drawing.draw(&PathElement::new(
                [(x, 100), (x + 27, 100)],
                colors[i].stroke_width(3),
            ))?;
            drawing.draw(&Text::new(
                labels[i],
                (x + 36, 91),
                ("sans-serif", 18).into_font().color(&ink),
            ))?;
        }
        drawing.draw(&Text::new(
            "Parcel pitch error relative to the continuously fine run",
            (24, 129),
            ("sans-serif", 18).into_font().color(&ink),
        ))?;
        let upper = drawing.clone().shrink((15, 151), (762, 192));
        let mut trace = ChartBuilder::on(&upper)
            .margin_top(4)
            .margin_right(8)
            .x_label_area_size(43)
            .y_label_area_size(67)
            .build_cartesian_2d(200.0_f64..239.2_f64, -0.235_f64..0.06_f64)?;
        trace
            .configure_mesh()
            .x_labels(8)
            .y_labels(6)
            .max_light_lines(0)
            .bold_line_style(grid)
            .y_label_formatter(&|y| format!("{y:.2}"))
            .x_label_formatter(&|x| format!("{x:.0}"))
            .label_style(("sans-serif", 13))
            .axis_desc_style(("sans-serif", 15))
            .x_desc("Simulation time (ms)")
            .y_desc("Pitch error (°)")
            .draw()?;
        for i in [2, 0, 1] {
            let errors: Vec<_> = runs[i]
                .pitch
                .iter()
                .zip(&runs[2].pitch)
                .enumerate()
                .map(|(j, (pitch, fine))| ((j + 1) as f64 * 0.2, pitch - fine))
                .filter(|(t, _)| (200.0..=239.2).contains(t))
                .collect();
            trace.draw_series(LineSeries::new(
                errors.iter().copied(),
                colors[i].stroke_width(if i == 2 { 3 } else { 2 }),
            ))?;
            let max = errors.iter().map(|(_, e)| f64::abs(*e)).fold(0.0, f64::max);
            summary.insert(keys[i].into(),json!({
                "pitch_error_end_of_pulse_deg":runs[i].pitch[1000]-runs[2].pitch[1000],
                "max_absolute_pitch_error_200_to_239_2ms_deg":max,
                "landing_peak_n":runs[i].peaks,"landing_peak_ns":runs[i].peak_times,
                "left_peak_time_error_us":(runs[i].peak_times[0] as i64-runs[2].peak_times[0] as i64) as f64/1000.,
                "normal_impulse_238_to_240ms_ns":runs[i].impulses,
                "public_ticks_by_native_step_count":runs[i].counts,
                "native_calls":runs[i].counts.iter().map(|(steps,ticks)|*steps * *ticks as u64).sum::<u64>()
            }));
        }
        drawing.draw(&Text::new(
            "Left pad force as the edge returns",
            (24, 363),
            ("sans-serif", 18).into_font().color(&ink),
        ))?;
        let lower = drawing.clone().shrink((15, 385), (762, 205));
        let mut impact = ChartBuilder::on(&lower)
            .margin_top(5)
            .margin_right(8)
            .x_label_area_size(44)
            .y_label_area_size(67)
            .build_cartesian_2d(238.35_f64..239.35_f64, 0.0_f64..207.)?;
        impact
            .configure_mesh()
            .x_labels(5)
            .y_labels(5)
            .max_light_lines(0)
            .bold_line_style(grid)
            .x_label_formatter(&|x| format!("{x:.1}"))
            .y_label_formatter(&|y| format!("{y:.0}"))
            .label_style(("sans-serif", 13))
            .axis_desc_style(("sans-serif", 15))
            .x_desc("Simulation time (ms)")
            .y_desc("Normal force (N)")
            .draw()?;
        for i in [2, 0, 1] {
            impact.draw_series(LineSeries::new(
                runs[i].force.iter().copied(),
                colors[i].stroke_width(if i == 2 { 4 } else { 2 }),
            ))?;
        }
        drawing.draw(&Text::new(
            "gz-web-rs replay",
            (817, 25),
            ("sans-serif", 26).into_font().color(&ink),
        ))?;
        drawing.draw(&Text::new(
            "219 ms   ·   Rocking on the pads",
            (818, 91),
            ("sans-serif", 17).into_font().color(&ink),
        ))?;
        drawing.draw(&Text::new(
            "239 ms   ·   Returning edge",
            (818, 350),
            ("sans-serif", 17).into_font().color(&ink),
        ))?;
        drawing.draw(&Text::new(
            "Time of peak force",
            (818, 575),
            ("sans-serif", 16).into_font().color(&subtle),
        ))?;
        drawing.draw(&Text::new(
            format!(
                "Earlier approach {:.3} ms   ·   Corrected {:.3} ms",
                runs[0].peak_times[0] as f64 * 1e-6,
                runs[1].peak_times[0] as f64 * 1e-6
            ),
            (818, 600),
            ("sans-serif", 15).into_font().color(&ink),
        ))?;
        drawing.present()?;
    }
    // Preserve the actual viewer pixels in both cutouts. Keep the SVG next to the run directories.
    let mut captures = String::new();
    for (y, name) in [(116, "edge"), (376, "strike")] {
        if !root.join("approach").join(format!("{name}.jpg")).is_file() {
            return Err("missing gz-web-rs capture".into());
        }
        captures.push_str(&format!(r##"<defs><clipPath id="{name}-crop"><rect x="818" y="{y}" width="325" height="187"/></clipPath></defs><g clip-path="url(#{name}-crop)"><image xmlns:xlink="http://www.w3.org/1999/xlink" transform="translate(818,{y}) scale(0.7336) translate(-528,-425)" xlink:href="approach/{name}.jpg" width="1440" height="900"/></g>"##));
    }
    let end = text.rfind("</svg>").ok_or("invalid SVG")?;
    text.insert_str(end, &captures);
    fs::write(svg_path, text)?;
    fs::write(summary_path, serde_json::to_vec_pretty(&summary)?)?;
    Ok(())
}
