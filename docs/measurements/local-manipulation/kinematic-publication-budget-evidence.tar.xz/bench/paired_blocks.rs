// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
use std::error::Error;
use std::io::{BufRead, BufReader, Write};
use std::path::Path;
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};

struct Runner {
    child: Child,
    input: ChildStdin,
    output: BufReader<ChildStdout>,
}
impl Runner {
    fn start(exe: &str, mode: &str, mask: &str, decks: &str) -> Result<Self, Box<dyn Error>> {
        let mut child = Command::new("taskset")
            .args([
                "-c", mask, exe, "--decks", decks, "--ticks", "256", "--reader", mode,
            ])
            .env("GZ_PUBLICATION_BLOCKS", "1")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .spawn()?;
        let input = child.stdin.take().unwrap();
        let output = BufReader::new(child.stdout.take().unwrap());
        let mut runner = Self {
            child,
            input,
            output,
        };
        if runner.line()? != "READY 21" {
            return Err("first block boundary missing".into());
        }
        Ok(runner)
    }
    fn line(&mut self) -> Result<String, Box<dyn Error>> {
        let mut line = String::new();
        self.output.read_line(&mut line)?;
        Ok(line.trim().to_owned())
    }
    fn advance(&mut self, block: usize) -> Result<Option<String>, Box<dyn Error>> {
        writeln!(self.input, "advance")?;
        self.input.flush()?;
        let output = self.line()?;
        if block == 7 {
            if !self.child.wait()?.success() || !output.starts_with('{') {
                return Err("benchmark failed before its final sample".into());
            }
            return Ok(Some(output));
        }
        if output != format!("READY {}", 21 + (block + 1) * 32) {
            return Err("unexpected public tick boundary".into());
        }
        Ok(None)
    }
}
impl Drop for Runner {
    fn drop(&mut self) {
        if matches!(self.child.try_wait(), Ok(None)) {
            let _ = self.child.kill();
            let _ = self.child.wait();
        }
    }
}
fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = std::env::args().skip(1).collect();
    let [base, trial, mode, out, repeat, mask, decks] = args.as_slice() else {
        return Err("expected BASE TRIAL sparse|full OUTPUT_DIR REPEAT CPU_MASK DECKS".into());
    };
    let first = (repeat.parse::<usize>()? + usize::from(mode == "full")) % 2;
    let exes = [base, trial];
    let mut runners: [Option<Runner>; 2] = [None, None];
    std::fs::create_dir_all(out)?;
    for index in [first, 1 - first] {
        runners[index] = Some(Runner::start(exes[index], mode, mask, decks)?);
    }
    for block in 0..8 {
        let next = (first + block) % 2;
        for index in [next, 1 - next] {
            if let Some(result) = runners[index].as_mut().unwrap().advance(block)? {
                let name = ["base", "trial"][index];
                std::fs::write(
                    Path::new(out).join(format!("{mode}-{name}-{repeat}.json")),
                    result + "\n",
                )?;
            }
        }
    }
    Ok(())
}
