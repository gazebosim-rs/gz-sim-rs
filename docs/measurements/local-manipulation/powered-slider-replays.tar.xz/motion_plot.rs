// Copyright (C) 2026 Open Source Robotics Foundation
// SPDX-License-Identifier: Apache-2.0
//! Plot the public slider encoder after each advancing tick, in physical units.
use plotters::prelude::*;
use serde_json::Value;
use std::{
    error::Error,
    fs::File,
    io::{BufRead, BufReader},
};
type Result<T> = std::result::Result<T, Box<dyn Error>>;
fn series(path: &str) -> Result<Vec<(f64, f64)>> {
    let mut points = vec![(0., 0.)];
    for row in BufReader::new(File::open(path)?).lines().skip(1) {
        let s: Value = serde_json::from_str(&row?)?;
        let ns = s["time_ns"].as_u64().ok_or("clock")?;
        if ns == 0 {
            continue;
        }
        let held = &s["held_joint_forces"][0];
        let q = s["scalar_joints"]
            .as_array()
            .ok_or("encoders")?
            .iter()
            .find(|j| j["id"] == held[0])
            .ok_or("slider")?["position"]
            .as_f64()
            .ok_or("position")?;
        points.push((
            ns as f64 * 1e-6,
            -q * held[1].as_f64().ok_or("input")?.signum() * 1e3,
        ));
    }
    Ok(points)
}
fn main() -> Result<()> {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    let [held, away, out] = args.as_slice() else {
        return Err("HELD_TRACE AWAY_TRACE OUTPUT.svg".into());
    };
    let (held, away) = (series(held)?, series(away)?);
    let canvas = SVGBackend::new(out, (760, 300)).into_drawing_area();
    canvas.fill(&WHITE)?;
    let title = canvas.titled("Finger travel away from the upper stop", ("sans-serif", 22))?;
    let mut chart = ChartBuilder::on(&title)
        .margin(10)
        .x_label_area_size(42)
        .y_label_area_size(65)
        .build_cartesian_2d(0f64..24f64, -0.10f64..2.30f64)?;
    chart
        .configure_mesh()
        .max_light_lines(0)
        .x_labels(7)
        .y_labels(6)
        .bold_line_style(RGBColor(218, 225, 232))
        .x_desc("Time (ms)")
        .y_desc("Travel (mm)")
        .light_line_style(RGBColor(228, 231, 236))
        .axis_desc_style(("sans-serif", 15))
        .draw()?;
    for (line, label, color) in [
        (away, "Strike away from stop", RGBColor(22, 120, 102)),
        (held, "Strike into stop", RGBColor(172, 76, 18)),
    ] {
        chart
            .draw_series(LineSeries::new(
                line.into_iter().step_by(25),
                color.stroke_width(3),
            ))?
            .label(label)
            .legend(move |(x, y)| PathElement::new([(x, y), (x + 25, y)], color.stroke_width(3)));
    }
    chart
        .configure_series_labels()
        .position(SeriesLabelPosition::UpperRight)
        .background_style(WHITE.mix(0.95))
        .border_style(RGBColor(178, 183, 191))
        .draw()?;
    canvas.present()?;
    Ok(())
}
