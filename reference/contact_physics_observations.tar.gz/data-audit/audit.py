# Copyright (C) 2026 Open Source Robotics Foundation
# SPDX-License-Identifier: Apache-2.0
"""SOURCE ONLY: Root reviews and executes retained data/hash audit in cb921 SDK."""
from pathlib import Path
import importlib.util,json,hashlib,math,statistics,re,tarfile,os,subprocess,tempfile
q=Path(__file__).resolve().parent
root=q.parents[1]
raw_digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
context=json.loads((q/'context.json').read_text());outcome=json.loads((q/'result.json').read_text())
build_root=Path(context['build_root']);baseline=Path(context['baseline_evidence']);paired=q/'paired'
expected=['crates/gz-physics-dart/src/bridge.cc','crates/gz-physics-dart/src/joint_state.hh','reference/b03_physics.json']
assert set(context['source_projection'])=={str(root/name)for name in expected}
assert context['source_projection']=={str(root/name):str(build_root/name)for name in expected}
projection={virtual:Path(actual)for actual,virtual in context['source_projection'].items()}
def digest(path):
 path=Path(path)
 return raw_digest(projection.get(str(path),path))
assert context['candidate_commit']=='f136e8211559dfdd831d39ce73e8132e413404a4'
assert context['candidate_tree']=='cdb53ed377800fe5dee6c349601b0dfd4efacd6b'
assert context['accepted_parent']=='e829be51d42fed27268606528ba758a93efc37a2'
assert context['cpu']==0
assert os.uname().release==context['hardware']['kernel_release']
assert os.uname().machine==context['hardware']['machine']
model=next(line.split(':',1)[1].strip()for line in Path('/proc/cpuinfo').read_text().splitlines()if line.startswith('model name'))
assert model==context['hardware']['cpu_model']
assert context['projected_sources_sha256']=={name:raw_digest(root/name)for name in expected}
assert context['source_projection']==outcome['source_projection']
command=json.loads((q/'command.json').read_text());argv=command['argv']
mounts=[argv[i+1]for i,value in enumerate(argv)if value=='--volume']
for actual,virtual in context['source_projection'].items():assert mounts.count(actual+':'+virtual+':ro')==1
assert command['context_sha256']==raw_digest(q/'context.json')
assert command['sources_before']==outcome['sources_after']
for path,value in command['sources_before'].items():assert raw_digest(path)==value
archive='reference/b03_physics_observations.tar.gz'
assert raw_digest(root/archive)==raw_digest(build_root/archive)==context['baseline_archive_sha256']=='a941e96b430504abd6229c3ac5e2a83f53397dd7603502f568307829ea586cb5'
# Historical Rust cache may now contain candidate artifacts; only archived old
# metadata and separately preserved ELF are authoritative baseline evidence.
with tarfile.open(root/archive,'r:gz')as tar:
 for name in ['native-build.json','native-closure.json']:
  assert tar.extractfile(name).read()==(baseline/name).read_bytes()
 assert hashlib.sha256(tar.extractfile('independent-audit.json').read()).hexdigest()=='37a92f3c5d7dd2a80c03cca800eb55069312b17b7170e5a80181de9f4e91fdb2'
normal=root/'artifacts/contact-factorization-corrected-staged'
assert raw_digest(normal/'result.json')==context['correctness_result_sha256']
correctness=json.loads((normal/'result.json').read_text())
assert correctness['exit_code']==0 and not correctness['capacity_stop'] and correctness['head']==context['candidate_commit']and correctness['source_tree']==context['candidate_tree']
assert raw_digest(normal/'independent-audit.json')=='ebe9393704a4e0c87dca3343a9ff643e8a35f29d8aac8329e02613b582057ce1'
spec=importlib.util.spec_from_file_location('benchmark_source',root/'scripts/benchmark-b03-physics.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
r=b.parse((paired/'result.json').read_bytes());ref=b.parse((root/'reference/b03_physics.json').read_bytes());wrapper=context['wrapper_tools_sha256'];cmd=b.parse((q/'command.json').read_bytes())
assert r['equal_work_eligible'] and r['full_server_equal_work']==False and r['product_default_change']==False
assert r['status']=='completed configured physics-only batch; not original-default/full-Server/rewrite acceptance'
assert r['paired_configuration_and_correctness']=='passed before measured pair1'
for p,h in r['input_sha256'].items():assert digest(p)==h,p
for p,h in wrapper.items():assert digest(p)==h,p
for name,h in r['output_sha256'].items():assert digest(paired/name)==h,name
assert len(r['output_sha256'])==112
assert json.loads((q/'result.json').read_text())['sources_unchanged']
assert json.loads((q/'paired-result.json').read_text())['exit_code']==0
assert json.loads((q/'rust-build-result.json').read_text())['exit_code']==0
assert outcome['tracked_source_clean_after'] and context['tracked_source_clean_before']
assert outcome['exit_code']==0 and outcome['stop'] is None
b.digest=lambda path:digest(path)  # Apply only the three recorded read-only build-view projections.
# Whitelisted actual capture command selects immutable no-network read-only SDK.
argv=cmd['argv'];assert '--read-only'in argv and argv[argv.index('--network')+1]=='none'
assert 'sha256:cb921fdafe5763b3c9148326dfd93b1cb291099f648702c4e27cc009137037ae'in argv
bins={'native':baseline/'native-physics','rust':baseline/'cargo-target/release/examples/b03_physics_query_benchmark'}
actors={'native':build_root/'reference/b03_physics.cc','rust':build_root/'crates/gz-sim-scene/examples/b03_physics_query_benchmark.rs'}
closures={};builds={}
for role in ['native','rust']:
 location=baseline if role=='native' else q
 closures[role]=b.known_role_closure(location/(role+'-closure.json'),b.ROLES[role],bins[role])
 builds[role]=b.build_record(location/(role+'-build.json'),role,bins[role],actors[role])
assert builds['native']['compile_argv']==json.loads((baseline/'native-build-command.json').read_text())
assert not set(builds['native']['inputs_sha256'])&set(projection), 'Native inputs must remain original, not projected'
assert raw_digest(baseline/'native-build.json')==context['baseline_native_build_sha256']
assert raw_digest(baseline/'native-closure.json')==context['baseline_native_closure_sha256']
assert raw_digest(baseline/'preserved-rust-baseline/b03_physics_query_benchmark')==context['preserved_baseline_executable_sha256']
# Existing rust metadata is a cache superset. Explicit externs are selected inputs.
selected_externs={}
binutils={name:{'path':str(Path('/usr/bin/'+name).resolve(strict=True)),
                'sha256':raw_digest(Path('/usr/bin/'+name).resolve(strict=True))}
          for name in ['ar','objcopy']}
def metadata_archive_binding(path,recorded):
 metadata=Path(path);assert metadata.suffix=='.rmeta'
 archive=metadata.with_suffix('.rlib');expected=recorded.get(str(archive))
 assert expected is not None and raw_digest(archive)==expected, 'Unrecorded/changed metadata archive'
 listing=subprocess.run([binutils['ar']['path'],'t',str(archive)],capture_output=True,check=True,timeout=30)
 assert not listing.stderr and listing.stdout.decode().splitlines().count('lib.rmeta')==1
 member=subprocess.run([binutils['ar']['path'],'p',str(archive),'lib.rmeta'],capture_output=True,check=True,timeout=30)
 assert not member.stderr and member.stdout.startswith(b'\x7fELF'), 'Metadata member is not the expected ELF wrapper'
 with tempfile.TemporaryDirectory(prefix='b03-metadata-audit-')as temporary:
  directory=Path(temporary);wrapped=directory/'lib.rmeta';section=directory/'metadata';copy=directory/'member-copy'
  wrapped.write_bytes(member.stdout)
  extracted=subprocess.run([binutils['objcopy']['path'],'--dump-section','.rmeta='+str(section),str(wrapped),str(copy)],capture_output=True,check=True,timeout=30)
  assert not extracted.stdout and not extracted.stderr and section.is_file()
  data=section.read_bytes()
  assert data and data==metadata.read_bytes(), 'Selected metadata differs from recorded archive section'
 assert raw_digest(archive)==expected
 for tool in binutils.values():assert raw_digest(tool['path'])==tool['sha256']
 return {'path':path,'sha256':hashlib.sha256(data).hexdigest(),
         'binding':'Exact .rmeta section of lib.rmeta ELF member in recorded, measurement-bracket-hashed .rlib; no separately recorded historical .rmeta file hash is claimed',
         'archive_path':str(archive),'archive_sha256':expected,'member':'lib.rmeta',
         'member_elf_sha256':hashlib.sha256(member.stdout).hexdigest(),
         'section':'.rmeta','section_sha256':hashlib.sha256(data).hexdigest()}
for label,argv in [('actor',builds['rust']['compile_argv']),('dart',builds['rust']['dart_compile_argv'])]:
 for i,arg in enumerate(argv):
  value=argv[i+1]if arg=='--extern' else arg[len('--extern='):]if arg.startswith('--extern=')else None
  if value is None:continue
  name,path=value.split('=',1);assert name and Path(path).is_absolute()
  if path in builds['rust']['inputs_sha256']:
   assert digest(path)==builds['rust']['inputs_sha256'][path]
   selected_externs[label+':'+name]={'path':path,'sha256':digest(path),'binding':'Direct recorded measurement-bracket-hashed input'}
  else:
   selected_externs[label+':'+name]=metadata_archive_binding(path,builds['rust']['inputs_sha256'])
assert selected_externs
assert builds['rust']['source_projection']==context['source_projection']
assert builds['rust']['direct_cpp_inputs_sha256']=={name:context['projected_sources_sha256'][name]for name in context['runtime_overlays']}
for path,value in builds['rust']['generated_native_outputs_sha256'].items():assert raw_digest(path)==value
assert any(Path(path).suffix=='.a'for path in builds['rust']['generated_native_outputs_sha256'])
# Hashes above cover actual compiler, SDK/source evidence and expanded deps.
for rel,h in ref['source_established_sha256'].items():assert digest(root/rel)==h
for rel,h in ref['native_source_established_sha256'].items():
 matches=[p for p,v in builds['native']['inputs_sha256'].items()if p.endswith('/'+rel)and v==h];assert len(matches)==1
manifest=[p for p,h in builds['native']['inputs_sha256'].items()if p.endswith('/zenoh-dart-environment.json')and h==ref['native_sdk']['manifest_sha256']];assert len(manifest)==1
for role in ['native','rust']:
 for name,h in ref['required_common_libraries_sha256'].items():assert len([p for p,v in closures[role]['files'].items()if Path(p).name==name and v==h])==1
plugin=[p for p,h in closures['native']['files'].items()if h==ref['native_plugin_sha256']];assert len(plugin)==1
fixture_path=root/'crates/gz-sim-scene/tests/fixtures/b03_world_fresh_native.json';assert digest(fixture_path)==ref['accepted_default_fixture_sha256'];fixture=json.loads(fixture_path.read_text())
assert len(r['pairs'])==8 and len(r['commands'])==len(r['runtime_closures'])==16
states={};values={};maxdelta=0;scalar_count=0
for pair in range(8):
 entry=r['pairs'][pair];order=['native','rust']if pair%2==0 else['rust','native'];assert entry['pair']==pair and entry['order']==order and entry['excluded_correctness_warmup']==(pair==0)
 mode='correctness'if pair==0 else'measure';states[pair]={};values[pair]={}
 for j,role in enumerate(order):
  p=paired/(str(pair)+'-'+role);record=r['commands'][pair*2+j];assert record['pair']==pair and record['role']==role
  args=record['argv'];assert args[:2]==['/usr/bin/time','-f'] and '/usr/bin/taskset'in args and args[args.index('--cpu-list')+1]==str(r['cpu'])
  assert str(bins[role])in args and args[-1]==mode and args[-2]==str(p)
  assert args[-3]==str(build_root/'crates/gz-sim-scene/tests/fixtures/b03_double_pendulum.sdf')
  assert not Path(str(p)+'.stderr').read_bytes()
  assert Path(str(p)+'.input.sdf').read_bytes()==b.XML.read_bytes()
  payload=b.parse(Path(str(p)+'.state.json').read_bytes());state=b.normalized(payload,role);config=b.settings(payload['settings'],role)
  if j==0:pair_settings=config
  else:assert pair_settings==config
  assert len(payload['entities'])==30
  state_metrics=b.parse(Path(str(p)+'.metrics.json').read_bytes());b.metrics(state_metrics,role,mode)
  runtime=r['runtime_closures'][pair*2+j];assert runtime['pair']==pair and runtime['role']==role
  mapped=b.verify_role_maps(Path(str(p)+'.maps'),closures[role],bins[role]);assert all(runtime[k]==v for k,v in mapped.items())
  times=Path(str(p)+'.process-time').read_text().split();assert len(times)==4
  metrics=dict(window_wall_ns=state_metrics['window_wall_ns'],process_user_seconds=float(times[0]),process_system_seconds=float(times[1]),process_wall_seconds=float(times[2]),peak_rss_kib=int(times[3]));assert metrics==entry[role]
  values[pair][role]=metrics;states[pair][role]=state
 # Independent scalar comparison, not an invocation of driver main/actors.
 count=0;maximum=0
 for a,c in zip(states[pair]['rust']['frames'],states[pair]['native']['frames']):
  assert a['tick']==c['tick'] and a['time_ns']==c['time_ns']
  for family,width in [('bodies',22),('joints',2)]:
   assert set(a[family])==set(c[family])
   for name,row in a[family].items():
    assert len(row)==len(c[family][name])==width
    for x,y in zip(row,c[family][name]):assert math.isfinite(x)and math.isfinite(y)and abs(x-y)<=1e-12;count+=1;maximum=max(maximum,abs(x-y))
 assert count==16200 and entry['comparison']==dict(values=count,maximum_delta=maximum,outside_1e_12=0,first_outside=None)
 scalar_count+=count;maxdelta=max(maxdelta,maximum)
 for role in ['native','rust']:
  if pair:assert b.comparison(states[pair][role],states[0][role])['outside_1e_12']==0
assert b.default_comparison(states[0]['native'],fixture)==r['configured_native_vs_default_selected']
assert b.default_comparison(states[0]['rust'],fixture)==r['rust_vs_compatible_default_selected']
summary={role:{metric:dict(median=statistics.median(vals),min=min(vals),max=max(vals))for metric in values[1][role]for vals in [[values[i][role][metric]for i in range(1,8)]]}for role in ['native','rust']};assert summary==r['summary']
ratio=summary['native']['window_wall_ns']['median']/summary['rust']['window_wall_ns']['median'];assert ratio==r['physics_only_native_over_rust_window_median']
print(json.dumps(dict(status='CLEAR',paired_result_sha256=digest(paired/'result.json'),input_files_rehashed=len(r['input_sha256']),output_files_rehashed=len(r['output_sha256']),build_inputs={role:len(v['inputs_sha256'])for role,v in builds.items()},mapped_roles=16,native_mapped_libraries=len(closures['native']['files']),rust_mapped_libraries=len(closures['rust']['files']),pairs=8,excluded_pairs=1,measured_pairs=7,scalar_comparisons=scalar_count,maximum_absolute_delta=maxdelta,outside_1e_12=0,configured_native_default_486=r['configured_native_vs_default_selected'],configured_rust_default_486=r['rust_vs_compatible_default_selected'],summary=summary,rust_over_native_window_median=1/ratio,source_projection=context['source_projection'],selected_extern_inputs=selected_externs,metadata_archive_tools={'immutable_image':'sha256:cb921fdafe5763b3c9148326dfd93b1cb291099f648702c4e27cc009137037ae','tools':binutils},source_build_input_scope='Recorded Rust inputs are a cache superset; actual actor/Dart extern inputs and generated native outputs are independently bound. Direct changed C++ bridge/header plus immutable SDK selection; no full C++ argv/transitive header inventory claim.',protocol_controls='Baseline12 reused, no repeat in candidate measurement; corrected normal254 includes five new oracle controls',scope='Configured physics-only step+query; Scene synchronization included. No full Server/default-settings/general rewrite speedup. Source/config/DSOs verified with capability labels; no private solver equivalence claimed.',limits=['Native explicit unlimited per-pair contact setting differs originalServer pair20. Global10000 source-established; unsupported Dantzig iterations null.','Windowwall is separate from wholeprocess GNUtime CPU/RSS; no highresolution windowCPU/RSS claims.','Only data/source/hash audit in immutable SDK; no actors/tests/compiler/probes/timing replay.','Original explicit-overflow/missing-time preactor failures and first316s oracle header-binding failure remain separately retained.','Corrected normal hook/local retained audit passed; exact hosted/official audit and Main acceptance remain separate. This script is retained-data/SDK audit only.']),indent=2))
