# Copyright (C) 2026 Open Source Robotics Foundation
# SPDX-License-Identifier: Apache-2.0
"""Source-only recipe: do not run before Root's correctness/review release."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

out = Path(__file__).resolve().parent
root = out.parents[1]
build_root = root.parent / 'b03-physics-benchmark-worktree'
baseline = build_root / 'artifacts/physics-qualification'
image = 'sha256:cb921fdafe5763b3c9148326dfd93b1cb291099f648702c4e27cc009137037ae'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
write = lambda p, value: Path(p).write_text(json.dumps(value, indent=2) + '\n')


def clean_candidate(commit, tree):
    current = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    index = subprocess.check_output(['git', 'write-tree'], cwd=root, text=True).strip()
    diff = subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--'], cwd=root)
    return current == commit and index == tree and diff.returncode == 0


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--correctness-result', type=Path, required=True)
args = parser.parse_args()
assert not (out / 'result.json').exists() and not (out / 'run.log').exists(), 'never overwrite an earlier run'
correctness = json.loads(args.correctness_result.read_text())
assert correctness['exit_code'] == 0 and not correctness['capacity_stop'], 'actual complete correctness gate must pass first'
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip()
assert correctness['head'] == commit and correctness['source_tree'] == tree
assert clean_candidate(commit, tree), 'tracked worktree/index must match qualified HEAD'
subprocess.run(['git', 'merge-base', '--is-ancestor', 'e829be51d42fed27268606528ba758a93efc37a2', commit], cwd=root, check=True)
runtime = ['crates/gz-physics-dart/src/bridge.cc', 'crates/gz-physics-dart/src/joint_state.hh']
projection = runtime + ['reference/b03_physics.json']
# Only the two reviewed native runtime files differ. The actor/driver, Rust
# production/build sources and manifests remain exact accepted-baseline bytes.
for manifest in root.glob('crates/*/Cargo.toml'):
    assert manifest.read_bytes() == (build_root / manifest.relative_to(root)).read_bytes()
    paths = list((manifest.parent / 'src').rglob('*.rs'))
    if (manifest.parent / 'build.rs').exists():
        paths.append(manifest.parent / 'build.rs')
    for path in paths:
        assert path.read_bytes() == (build_root / path.relative_to(root)).read_bytes(), path
for name in ['Cargo.toml', 'Cargo.lock', 'reference/b03_physics.cc',
             'scripts/benchmark-b03-physics.py', 'crates/gz-sim-scene/examples/b03_physics_query_benchmark.rs',
             'crates/gz-sim-scene/tests/fixtures/b03_double_pendulum.sdf']:
    assert (root / name).read_bytes() == (build_root / name).read_bytes(), name
original = json.loads((build_root / 'reference/b03_physics.json').read_text())
projected = json.loads((root / 'reference/b03_physics.json').read_text())
expected = json.loads(json.dumps(original))
expected['source_established_sha256'][runtime[0]] = sha(root / runtime[0])
assert projected == expected, 'contract settings may not change for this comparison'
archive = 'reference/b03_physics_observations.tar.gz'
assert sha(root / archive) == sha(build_root / archive) == 'a941e96b430504abd6229c3ac5e2a83f53397dd7603502f568307829ea586cb5'
old_build = json.loads((baseline / 'rust-build.json').read_text())
old_exe = baseline / 'cargo-target/release/examples/b03_physics_query_benchmark'
old_dep = old_exe.with_suffix('.d')
assert sha(old_exe) == old_build['executable_sha256']
# Preserve just the non-regenerable baseline executable/dep-info before warm
# Cargo replaces them, outside the mutable target. Never copy the whole graph.
preserved = baseline / 'preserved-rust-baseline'
preserved.mkdir(exist_ok=True)
for source in [old_exe, old_dep]:
    destination = preserved / source.name
    if destination.exists():
        assert sha(destination) == sha(source)
    else:
        shutil.copy2(source, destination)
        assert sha(destination) == sha(source)
# Keep the exact accepted Cargo home path as well as the target path, so
# unchanged registry/path-crate identities do not move for this rebuild.
cache = baseline / 'cargo-home'
assert cache.is_dir()
for name in ['registry', 'git']:
    link = cache / name
    assert link.is_symlink() and link.resolve() == Path('/home/nkoenig/.cargo') / name
toolchain = Path('/home/nkoenig/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu')
prior = json.loads((baseline / 'paired/result.json').read_text())
cpu = prior['cpu']
assert cpu in os.sched_getaffinity(0)
wrappers = json.loads((baseline / 'wrapper-tools.json').read_text())
assert sha('/usr/bin/time') == wrappers['/usr/bin/time']
cpu_model = next(line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name'))
context = {'hardware': {'kernel_release': os.uname().release, 'machine': os.uname().machine, 'cpu_model': cpu_model, 'allowed_affinity': sorted(os.sched_getaffinity(0))},
           'candidate_commit': commit, 'candidate_tree': tree,
           'tracked_source_clean_before': True,
           'accepted_parent': 'e829be51d42fed27268606528ba758a93efc37a2',
           'correctness_result_sha256': sha(args.correctness_result),
           'build_root': str(build_root), 'candidate_root': str(root), 'baseline_evidence': str(baseline),
           'cpu': cpu, 'runtime_overlays': runtime,
           'projected_sources_sha256': {name: sha(root / name) for name in projection},
           'source_projection': {str(root / name): str(build_root / name) for name in projection},
           'plugin': '/reference/zenoh-dart-install/lib/gz-physics/engine-plugins/libgz-physics-dartsim-plugin.so.10.0.0~pre2',
           'wrapper_tools_sha256': wrappers,
           'baseline_native_build_sha256': sha(baseline / 'native-build.json'),
           'baseline_native_closure_sha256': sha(baseline / 'native-closure.json'),
           'baseline_archive_sha256': sha(root / archive),
           'preserved_baseline_executable_sha256': old_build['executable_sha256']}
write(out / 'context.json', context)
argv = ['docker', 'run', '--rm', '--network', 'none', '--read-only',
        '--user', f'{os.getuid()}:{os.getgid()}', '--tmpfs', '/tmp:rw,exec,size=2g', '--workdir', str(build_root)]
mounts = [(build_root, build_root, 'ro'), (root, root, 'ro'), (out, out, 'rw'),
          (baseline / 'cargo-target', baseline / 'cargo-target', 'rw'),
          (cache, cache, 'rw'),
          (root.parents[1] / '.git', root.parents[1] / '.git', 'ro'),
          (toolchain, toolchain, 'ro'), (Path('/home/nkoenig/.cargo/registry'), Path('/home/nkoenig/.cargo/registry'), 'ro'),
          (Path('/home/nkoenig/.cargo/git'), Path('/home/nkoenig/.cargo/git'), 'ro'),
          (root.parent / 'physics-reference/mujoco', root.parent / 'physics-reference/mujoco', 'ro'),
          (Path('/usr/bin/time'), Path('/usr/bin/time'), 'ro')]
mounts += [(root / name, build_root / name, 'ro') for name in projection]
for source, target, mode in mounts:
    assert source.exists(), source
    argv += ['--volume', f'{source}:{target}:{mode}']
values = {'HOME': '/tmp', 'PATH': '/usr/bin:/bin', 'PYTHONDONTWRITEBYTECODE': '1',
          'CARGO_HOME': str(cache), 'CARGO_TARGET_DIR': str(baseline / 'cargo-target'),
          'CARGO_NET_OFFLINE': 'true', 'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
          'CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS': 'true', 'CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS': 'true',
          'CARGO_PROFILE_RELEASE_DEBUG': '0', 'RUSTFLAGS': '-C overflow-checks=yes',
          'RUSTC': str(toolchain / 'bin/rustc'), 'BENCH_CARGO': str(toolchain / 'bin/cargo'),
          'BENCH_PYTHON': '/usr/bin/python3', 'PROTOC': '/usr/bin/protoc',
          'MUJOCO_PREFIX': str(root.parent / 'physics-reference/mujoco'),
          'PKG_CONFIG_PATH': '/reference/zenoh-dart-install/lib/pkgconfig:/zenoh-dart-client/install/lib/pkgconfig:/reference/install/lib/pkgconfig',
          'LD_LIBRARY_PATH': '/reference/zenoh-dart-builds/gz-physics/lib:/reference/zenoh-dart-install/lib:/zenoh-dart-client/install/lib:/reference/install/lib'}
for key, value in values.items():
    argv += ['--env', key + '=' + value]
argv += ['--entrypoint', '/usr/bin/python3', image, str(out / 'inside.py')]
watched = [root / name for name in projection] + [out / 'run.py', out / 'inside.py', root / archive, root / 'Cargo.lock',
           root / 'crates/gz-sim-scene/examples/b03_physics_query_benchmark.rs',
           build_root / archive, baseline / 'native-physics', baseline / 'native-build.json', baseline / 'native-closure.json']
before = {str(path): sha(path) for path in watched}
write(out / 'command.json', {'argv': argv, 'context_sha256': sha(out / 'context.json'),
                             'sources_before': before, 'image': image,
                             'scope': 'Explicit three-file read-only source projection for warm Cargo identities; actual candidate bytes, not a source/default-URI equivalence claim. Root coordinates no concurrent builds during timing.'})
minimum = shutil.disk_usage(root).free
assert minimum > 1024**3
start = time.monotonic()
stop = None
with (out / 'run.log').open('xb') as log:
    child = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    while child.poll() is None:
        free = shutil.disk_usage(root).free
        minimum = min(minimum, free)
        if free < 1024**3 or time.monotonic() - start > 1800:
            stop = 'capacity' if free < 1024**3 else 'timeout'
            os.killpg(child.pid, signal.SIGINT)
            try:
                child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            break
        time.sleep(1)
    code = child.wait()
after = {str(path): sha(path) for path in watched}
tracked_clean = clean_candidate(commit, tree)
result = {'exit_code': code, 'stop': stop, 'minimum_free_bytes': minimum,
          'elapsed_seconds': time.monotonic() - start, 'sources_after': after,
          'sources_unchanged': before == after, 'tracked_source_clean_after': tracked_clean,
          'source_projection': context['source_projection']}
write(out / 'result.json', result)
print(json.dumps(result))
raise SystemExit(0 if code == 0 and before == after and tracked_clean else 1)
