# Copyright (C) 2026 Open Source Robotics Foundation
# SPDX-License-Identifier: Apache-2.0
"""Reviewed recipe source only; Root releases compilation and measurement."""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess

out = Path(__file__).resolve().parent
context = json.loads((out / 'context.json').read_text())
root = Path(context['build_root'])
baseline = Path(context['baseline_evidence'])
env = os.environ.copy()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
write = lambda p, value: Path(p).write_text(json.dumps(value, indent=2) + '\n')

def run(name, argv):
    write(out / (name + '-command.json'), argv)
    with (out / (name + '.log')).open('xb') as log:
        result = subprocess.run(argv, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    write(out / (name + '-result.json'), {'exit_code': result.returncode})
    if result.returncode:
        raise SystemExit(result.returncode)


def depnames(path):
    text = path.read_text().replace('\\\n', ' ').split('\n\n', 1)[0]
    return {Path(p).resolve() for p in shlex.split(text.split(':', 1)[1]) if Path(p).is_file()}


for name, value in context['projected_sources_sha256'].items():
    assert sha(root / name) == value, name
native = baseline / 'native-physics'
native_build = json.loads((baseline / 'native-build.json').read_text())
assert sha(native) == native_build['executable_sha256']
assert {p: sha(p) for p in context['wrapper_tools_sha256']} == context['wrapper_tools_sha256']

# Same Cargo paths/cache and release settings as the accepted build. The only
# runtime source replacements are the two declared read-only file mounts.
argv = [env['BENCH_CARGO'], 'build', '--release', '--locked', '--offline',
        '--package', 'gz-sim-scene', '--example', 'b03_physics_query_benchmark', '-vv']
run('rust-build', argv)
lines = (out / 'rust-build.log').read_text().splitlines()
def actual_rustc(crate):
    line = next(line for line in reversed(lines)
                if 'Running `' in line and '--crate-name ' + crate + ' ' in line)
    tokens = shlex.split(line.split('`', 2)[1])
    index = next(i for i, token in enumerate(tokens) if Path(token).name == 'rustc')
    return tokens[index:]

rust_argv = actual_rustc('b03_physics_query_benchmark')
dart_argv = actual_rustc('gz_physics_dart')
target = Path(env['CARGO_TARGET_DIR'])
rust = target / 'release/examples/b03_physics_query_benchmark'
actor = root / 'crates/gz-sim-scene/examples/b03_physics_query_benchmark.rs'
inputs = {actor, Path(rust_argv[0]).resolve(), root / 'Cargo.toml', root / 'Cargo.lock'}
for manifest in (root / 'crates').glob('*/Cargo.toml'):
    inputs.add(manifest)
    inputs.update((manifest.parent / 'src').rglob('*.rs'))
    if (manifest.parent / 'build.rs').exists():
        inputs.add(manifest.parent / 'build.rs')
inputs.update((target / 'release/deps').glob('*.rlib'))
inputs.update(depnames(target / 'release/examples/b03_physics_query_benchmark.d'))
for name in ['src/bridge.cc', 'src/joint_state.hh', 'include/bridge.h']:
    inputs.add(root / 'crates/gz-physics-dart' / name)
# Retain the actual generated C++ objects/archive/header inputs selected by the
# Dart crate invocation. This is not a claim of a new SDK compilation or a
# complete transitive C++ header-dependency trace.
native_outputs = set()
for i, token in enumerate(dart_argv):
    value = dart_argv[i + 1] if token == '-L' and i + 1 < len(dart_argv) else token[2:] if token.startswith('-L') else ''
    if value.startswith('native='):
        directory = Path(value.split('=', 1)[1])
        if directory.name == 'out' and directory.parent.name.startswith('gz-physics-dart-'):
            native_outputs.update(p.resolve() for p in directory.rglob('*') if p.is_file())
assert native_outputs, 'Dart generated native output is not bound'
inputs.update(native_outputs)
write(out / 'rust-build.json', {
    'role': 'rust-scene-physics', 'executable_sha256': sha(rust),
    'compile_argv': rust_argv,
    'inputs_sha256': {str(p.resolve()): sha(p) for p in sorted(inputs)},
    'dart_compile_argv': dart_argv,
    'direct_cpp_inputs_sha256': {name: sha(root / name) for name in context['runtime_overlays']},
    'generated_native_outputs_sha256': {str(p): sha(p) for p in sorted(native_outputs)},
    'source_projection': context['source_projection'],
    'native_input_scope': 'Actual rustc inputs/link artifacts, direct bridge/header sources and selected generated native outputs. Immutable SDK/compiler selection is inherited; no claim of a separately observed complete C++ compiler argv/transitive dependency inventory.'})
text = subprocess.check_output(['/usr/bin/ldd', str(rust)], env=env, text=True)
(out / 'rust.ldd').write_text(text)
assert 'not found' not in text
files = set()
for line in text.splitlines():
    match = re.search(r'(?:=>\s*)?(/\S+)\s+\(', line)
    if match:
        files.add(Path(match.group(1)).resolve())
files.discard(rust.resolve())
write(out / 'rust-closure.json', {'role': 'rust-scene-physics', 'executable_sha256': sha(rust),
                                'files': {str(p): sha(p) for p in sorted(files)}})
# The accepted native executable, build argv/inputs and known closure are reused
# in place, read-only. The unchanged driver verifies their actual maps per run.
argv = [env['BENCH_PYTHON'], str(root / 'scripts/benchmark-b03-physics.py'),
        '--native', str(native), '--rust', str(rust), '--plugin', context['plugin'],
        '--native-build-record', str(baseline / 'native-build.json'),
        '--rust-build-record', str(out / 'rust-build.json'),
        '--native-closure', str(baseline / 'native-closure.json'),
        '--rust-closure', str(out / 'rust-closure.json'),
        '--cpu', str(context['cpu']), '--output', str(out / 'paired')]
run('paired', argv)
assert {p: sha(p) for p in context['wrapper_tools_sha256']} == context['wrapper_tools_sha256']
